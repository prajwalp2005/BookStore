// Format currency
export const formatPrice = (amount) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);

// Format date
export const formatDate = (dateStr) =>
  new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(dateStr));

// Format relative time
export const timeAgo = (dateStr) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 30) return formatDate(dateStr);
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
};

// Truncate text
export const truncate = (str, n) => str?.length > n ? str.slice(0, n) + '...' : str;

// Discount percent
export const discountPercent = (original, current) =>
  original > current ? Math.round(((original - current) / original) * 100) : 0;

// Image fallback
export const bookFallback = (title) =>
  `https://ui-avatars.com/api/?name=${encodeURIComponent(title || 'Book')}&size=400&background=e35d18&color=fff&font-size=0.2&bold=true&format=svg`;

// Order status color
export const statusColor = (status) => {
  const map = {
    Pending:   'bg-amber-100 text-amber-800',
    Confirmed: 'bg-blue-100 text-blue-800',
    Shipped:   'bg-indigo-100 text-indigo-800',
    Delivered: 'bg-green-100 text-green-800',
    Cancelled: 'bg-red-100 text-red-800',
    Returned:  'bg-gray-100 text-gray-800',
  };
  return map[status] || 'bg-gray-100 text-gray-600';
};

// Payment status color
export const paymentColor = (status) => {
  const map = { pending: 'text-amber-600', paid: 'text-green-600', failed: 'text-red-600', refunded: 'text-blue-600' };
  return map[status] || 'text-gray-600';
};

// Star rating array
export const starArray = (rating) => {
  return Array.from({ length: 5 }, (_, i) => {
    if (i < Math.floor(rating)) return 'full';
    if (i < rating) return 'half';
    return 'empty';
  });
};

// Categories with icons
export const CATEGORIES = [
  { name: 'Fiction',      icon: '📖', color: 'from-blue-400 to-blue-600' },
  { name: 'Non-Fiction',  icon: '📰', color: 'from-green-400 to-green-600' },
  { name: 'Academic',     icon: '🎓', color: 'from-purple-400 to-purple-600' },
  { name: 'Science',      icon: '🔬', color: 'from-cyan-400 to-cyan-600' },
  { name: 'Technology',   icon: '💻', color: 'from-slate-400 to-slate-600' },
  { name: 'History',      icon: '🏛️', color: 'from-amber-400 to-amber-600' },
  { name: 'Biography',    icon: '👤', color: 'from-rose-400 to-rose-600' },
  { name: 'Self-Help',    icon: '🌱', color: 'from-lime-400 to-lime-600' },
  { name: 'Children',     icon: '🧒', color: 'from-yellow-400 to-yellow-600' },
  { name: 'Mystery',      icon: '🔍', color: 'from-gray-500 to-gray-700' },
  { name: 'Romance',      icon: '💕', color: 'from-pink-400 to-pink-600' },
  { name: 'Fantasy',      icon: '🧙', color: 'from-violet-400 to-violet-600' },
  { name: 'Horror',       icon: '👻', color: 'from-red-400 to-red-600' },
  { name: 'Poetry',       icon: '✍️', color: 'from-teal-400 to-teal-600' },
  { name: 'Comics',       icon: '🦸', color: 'from-orange-400 to-orange-600' },
];

// Sort options
export const SORT_OPTIONS = [
  { value: 'newest',     label: 'Newest First' },
  { value: 'oldest',     label: 'Oldest First' },
  { value: 'price-asc',  label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'rating',     label: 'Highest Rated' },
  { value: 'popular',    label: 'Most Popular' },
];
