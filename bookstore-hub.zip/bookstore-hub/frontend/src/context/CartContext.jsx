import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const { user } = useAuth();
  const [cart, setCart] = useState({ items: [] });
  const [wishlist, setWishlist] = useState({ books: [] });
  const [cartLoading, setCartLoading] = useState(false);

  const fetchCart = useCallback(async () => {
    if (!user) { setCart({ items: [] }); return; }
    try {
      const [cartRes, wlRes] = await Promise.all([
        api.get('/store/cart'),
        api.get('/store/wishlist'),
      ]);
      setCart(cartRes.data.cart || { items: [] });
      setWishlist(wlRes.data.wishlist || { books: [] });
    } catch (_) {}
  }, [user]);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const addToCart = useCallback(async (bookId, quantity = 1) => {
    if (!user) { toast.error('Please login to add items to cart'); return false; }
    try {
      const res = await api.post('/store/cart', { bookId, quantity });
      setCart(res.data.cart);
      toast.success('Added to cart!');
      return true;
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add to cart');
      return false;
    }
  }, [user]);

  const updateCartItem = useCallback(async (bookId, quantity) => {
    try {
      const res = await api.put('/store/cart', { bookId, quantity });
      setCart(res.data.cart);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update cart');
    }
  }, []);

  const removeFromCart = useCallback(async (bookId) => {
    try {
      const res = await api.delete(`/store/cart/${bookId}`);
      setCart(res.data.cart);
      toast.success('Removed from cart');
    } catch (err) {
      toast.error('Failed to remove item');
    }
  }, []);

  const clearCart = useCallback(async () => {
    try {
      await api.delete('/store/cart');
      setCart({ items: [] });
    } catch (_) {}
  }, []);

  const toggleWishlist = useCallback(async (bookId) => {
    if (!user) { toast.error('Please login to use wishlist'); return; }
    try {
      const res = await api.post('/store/wishlist', { bookId });
      setWishlist(res.data.wishlist);
      toast.success(res.data.action === 'added' ? 'Added to wishlist!' : 'Removed from wishlist');
    } catch (_) {
      toast.error('Failed to update wishlist');
    }
  }, [user]);

  const isInWishlist = useCallback((bookId) => {
    return wishlist?.books?.some(b => (b._id || b) === bookId);
  }, [wishlist]);

  const cartCount = cart?.items?.reduce((sum, i) => sum + i.quantity, 0) || 0;
  const cartTotal = cart?.items?.reduce((sum, i) => sum + (i.book?.price || 0) * i.quantity, 0) || 0;

  return (
    <CartContext.Provider value={{
      cart, wishlist, cartLoading, cartCount, cartTotal,
      addToCart, updateCartItem, removeFromCart, clearCart,
      toggleWishlist, isInWishlist, fetchCart,
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
};
