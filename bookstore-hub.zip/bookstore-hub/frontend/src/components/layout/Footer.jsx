import { Link } from 'react-router-dom';
import { BookOpen, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-ink-950 text-ink-300 mt-auto">
      <div className="max-w-7xl mx-auto px-6 pt-14 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center">
                <BookOpen size={20} className="text-white" />
              </div>
              <span className="font-display font-bold text-xl text-white">
                Book<span className="text-brand-400">Store</span> Hub
              </span>
            </Link>
            <p className="text-sm leading-relaxed text-ink-400 font-sans mb-5">
              Your premier destination for books of every genre. Discover, purchase, and explore a world of knowledge and imagination.
            </p>
            <div className="flex items-center gap-3">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-8 h-8 rounded-lg bg-ink-800 flex items-center justify-center hover:bg-brand-500 transition-colors">
                  <Icon size={14} className="text-ink-300" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-sans font-semibold text-white mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2.5">
              {[
                { to: '/books', label: 'Browse Books' },
                { to: '/books?featured=true', label: 'Featured Books' },
                { to: '/books?sort=newest', label: 'New Arrivals' },
                { to: '/books?sort=rating', label: 'Best Sellers' },
                { to: '/register?role=seller', label: 'Become a Seller' },
              ].map(({ to, label }) => (
                <li key={to}>
                  <Link to={to} className="text-sm text-ink-400 hover:text-brand-400 transition-colors font-sans">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-sans font-semibold text-white mb-4 text-sm uppercase tracking-wider">Categories</h4>
            <ul className="space-y-2.5">
              {['Fiction','Non-Fiction','Academic','Technology','Science','History','Biography','Self-Help'].map(cat => (
                <li key={cat}>
                  <Link to={`/books?category=${cat}`} className="text-sm text-ink-400 hover:text-brand-400 transition-colors font-sans">
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-sans font-semibold text-white mb-4 text-sm uppercase tracking-wider">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-ink-400 font-sans">
                <MapPin size={15} className="mt-0.5 flex-shrink-0 text-brand-400" />
                123 Book Lane, Library District, Mumbai – 400001
              </li>
              <li className="flex items-center gap-3 text-sm text-ink-400 font-sans">
                <Phone size={15} className="flex-shrink-0 text-brand-400" />
                +91 98765 43210
              </li>
              <li className="flex items-center gap-3 text-sm text-ink-400 font-sans">
                <Mail size={15} className="flex-shrink-0 text-brand-400" />
                hello@bookstorehub.com
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-ink-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-ink-500 font-sans text-center">
            © {new Date().getFullYear()} Book Store Hub. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            {['Privacy Policy','Terms of Service','Refund Policy'].map(item => (
              <a key={item} href="#" className="text-xs text-ink-500 hover:text-ink-300 transition-colors font-sans">
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
