import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, Heart, User, Search, Menu, X, BookOpen, ChevronDown, LogOut, Package, Settings, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef(null);

  useEffect(() => {
    setMobileMenuOpen(false);
    setUserMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const handleClick = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/books?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const dashboardLink = user?.role === 'admin' ? '/admin' : user?.role === 'seller' ? '/seller' : '/dashboard';

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-ink-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center h-16 gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center">
              <BookOpen size={18} className="text-white" />
            </div>
            <span className="font-display font-bold text-xl text-ink-900 hidden sm:block">
              Book<span className="text-brand-500">Store</span> Hub
            </span>
          </Link>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-xl hidden md:flex">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books, authors, genres..."
                className="w-full pl-4 pr-12 py-2 rounded-xl border border-ink-200 bg-ink-50 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-brand-400 focus:bg-white transition-all"
              />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 hover:text-brand-500 transition-colors">
                <Search size={16} />
              </button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-1 ml-auto">
            {/* Mobile search */}
            <button className="md:hidden btn-ghost p-2" onClick={() => navigate('/books')}>
              <Search size={20} />
            </button>

            {user ? (
              <>
                {/* Cart */}
                <Link to="/cart" className="relative btn-ghost p-2">
                  <ShoppingCart size={20} />
                  {cartCount > 0 && (
                    <span className="notif-dot">{cartCount > 9 ? '9+' : cartCount}</span>
                  )}
                </Link>

                {/* Wishlist */}
                <Link to="/wishlist" className="btn-ghost p-2 hidden sm:flex">
                  <Heart size={20} />
                </Link>

                {/* User menu */}
                <div className="relative" ref={userMenuRef}>
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 btn-ghost px-2 py-1.5"
                  >
                    {user.avatar ? (
                      <img src={user.avatar} alt={user.name} className="w-7 h-7 rounded-full object-cover" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center">
                        <span className="text-brand-700 text-xs font-bold">{user.name[0].toUpperCase()}</span>
                      </div>
                    )}
                    <span className="text-sm font-medium hidden sm:block max-w-[100px] truncate">{user.name.split(' ')[0]}</span>
                    <ChevronDown size={14} className={`transition-transform hidden sm:block ${userMenuOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {userMenuOpen && (
                    <div className="absolute right-0 top-full mt-2 w-52 bg-white rounded-xl shadow-lg border border-ink-100 py-1 z-50 animate-[fadeSlideIn_0.15s_ease-out]">
                      <div className="px-4 py-2.5 border-b border-ink-100">
                        <p className="font-semibold text-sm text-ink-900 truncate">{user.name}</p>
                        <p className="text-xs text-ink-500 truncate">{user.email}</p>
                        <span className="badge bg-brand-100 text-brand-700 mt-1">{user.role}</span>
                      </div>
                      <Link to={dashboardLink} className="flex items-center gap-3 px-4 py-2.5 text-sm text-ink-700 hover:bg-ink-50 transition-colors">
                        <LayoutDashboard size={15} /> Dashboard
                      </Link>
                      <Link to="/orders" className="flex items-center gap-3 px-4 py-2.5 text-sm text-ink-700 hover:bg-ink-50 transition-colors">
                        <Package size={15} /> My Orders
                      </Link>
                      <Link to="/profile" className="flex items-center gap-3 px-4 py-2.5 text-sm text-ink-700 hover:bg-ink-50 transition-colors">
                        <Settings size={15} /> Profile Settings
                      </Link>
                      <div className="border-t border-ink-100 mt-1">
                        <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors">
                          <LogOut size={15} /> Sign Out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login" className="btn-ghost text-sm px-3 py-2">Sign In</Link>
                <Link to="/register" className="btn-primary text-sm px-4 py-2">Get Started</Link>
              </div>
            )}

            {/* Mobile menu */}
            <button className="md:hidden btn-ghost p-2 ml-1" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-3 border-t border-ink-100 space-y-1 animate-[fadeSlideIn_0.2s_ease-out]">
            <form onSubmit={handleSearch} className="px-1 mb-3">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search books..."
                  className="input pl-4 pr-10"
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400">
                  <Search size={16} />
                </button>
              </div>
            </form>
            <Link to="/books" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-ink-700 hover:bg-ink-50">All Books</Link>
            {user && <Link to="/wishlist" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-ink-700 hover:bg-ink-50"><Heart size={16}/>Wishlist</Link>}
          </div>
        )}
      </div>

      {/* Category nav */}
      <nav className="hidden md:block bg-ink-950 text-white">
        <div className="max-w-7xl mx-auto px-6 flex items-center gap-1 h-9 overflow-x-auto no-scrollbar">
          <Link to="/books" className="text-xs font-sans font-medium text-ink-300 hover:text-white px-3 py-1 rounded transition-colors whitespace-nowrap">All Books</Link>
          {['Fiction','Non-Fiction','Academic','Technology','Science','History','Biography','Self-Help','Fantasy','Mystery','Romance'].map(cat => (
            <Link key={cat} to={`/books?category=${cat}`} className="text-xs font-sans font-medium text-ink-400 hover:text-white px-3 py-1 rounded transition-colors whitespace-nowrap">
              {cat}
            </Link>
          ))}
        </div>
      </nav>
    </header>
  );
}
