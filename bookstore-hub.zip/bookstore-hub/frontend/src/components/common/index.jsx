import { Star, StarHalf, Heart, ShoppingCart, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatPrice, bookFallback, starArray, discountPercent } from '../../utils/helpers';
import { useCart } from '../../context/CartContext';

// ── StarRating ────────────────────────────────────────────────────────────────
export function StarRating({ rating = 0, size = 14, showCount, count }) {
  const stars = starArray(Number(rating));
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center gap-0.5">
        {stars.map((type, i) => (
          <span key={i}>
            {type === 'full' ? (
              <Star size={size} className="star-filled" />
            ) : type === 'half' ? (
              <StarHalf size={size} className="star-filled" />
            ) : (
              <Star size={size} className="star-empty" />
            )}
          </span>
        ))}
      </div>
      {showCount && <span className="text-xs text-ink-500 font-sans">({count?.toLocaleString() || 0})</span>}
    </div>
  );
}

// ── BookCard ──────────────────────────────────────────────────────────────────
export function BookCard({ book, view = 'grid' }) {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const inWishlist = isInWishlist(book._id);
  const discount = discountPercent(book.originalPrice, book.price);

  if (view === 'list') {
    return (
      <div className="card card-hover flex gap-4 p-4 group">
        <Link to={`/books/${book._id}`} className="flex-shrink-0">
          <div className="w-24 h-32 rounded-lg overflow-hidden bg-ink-100">
            <img
              src={book.images?.[0]?.url || bookFallback(book.title)}
              alt={book.title}
              className="book-cover"
              onError={e => { e.target.src = bookFallback(book.title); }}
            />
          </div>
        </Link>
        <div className="flex-1 min-w-0">
          <Link to={`/books/${book._id}`}>
            <h3 className="font-display font-semibold text-ink-900 hover:text-brand-600 transition-colors line-clamp-2 leading-snug">{book.title}</h3>
          </Link>
          <p className="text-sm text-ink-500 font-sans mt-0.5">{book.author}</p>
          <div className="flex items-center gap-2 mt-1.5">
            <StarRating rating={book.ratings} size={12} showCount count={book.numReviews} />
          </div>
          <p className="text-xs text-ink-400 font-sans mt-1.5 line-clamp-2">{book.description}</p>
          <div className="flex items-center gap-3 mt-3">
            <span className="font-display font-bold text-lg text-ink-900">{formatPrice(book.price)}</span>
            {book.originalPrice > book.price && (
              <>
                <span className="text-sm text-ink-400 line-through font-sans">{formatPrice(book.originalPrice)}</span>
                <span className="badge bg-green-100 text-green-700">{discount}% off</span>
              </>
            )}
            <button
              onClick={() => addToCart(book._id)}
              className="ml-auto btn-primary text-xs px-3 py-1.5 flex items-center gap-1.5"
              disabled={book.stock === 0}
            >
              <ShoppingCart size={13} />
              {book.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card card-hover group relative">
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5">
        {discount > 0 && <span className="badge bg-green-500 text-white">{discount}% OFF</span>}
        {book.isFeatured && <span className="badge bg-brand-500 text-white">Featured</span>}
        {book.stock === 0 && <span className="badge bg-red-100 text-red-700">Out of Stock</span>}
      </div>

      {/* Wishlist */}
      <button
        onClick={() => toggleWishlist(book._id)}
        className={`absolute top-3 right-3 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
          inWishlist ? 'bg-red-500 text-white' : 'bg-white/80 text-ink-400 hover:text-red-500 hover:bg-white'
        } shadow-sm`}
      >
        <Heart size={14} fill={inWishlist ? 'currentColor' : 'none'} />
      </button>

      {/* Cover */}
      <Link to={`/books/${book._id}`} className="block overflow-hidden aspect-[3/4] bg-ink-100">
        <img
          src={book.images?.[0]?.url || bookFallback(book.title)}
          alt={book.title}
          className="book-cover"
          onError={e => { e.target.src = bookFallback(book.title); }}
        />
        <div className="absolute inset-0 bg-ink-900/0 group-hover:bg-ink-900/20 transition-all flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 transition-all bg-white text-ink-900 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-lg">
            <Eye size={12} /> Quick View
          </span>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <p className="text-xs text-brand-600 font-sans font-medium mb-1">{book.category}</p>
        <Link to={`/books/${book._id}`}>
          <h3 className="font-display font-semibold text-ink-900 hover:text-brand-600 transition-colors line-clamp-2 text-sm leading-snug mb-0.5">
            {book.title}
          </h3>
        </Link>
        <p className="text-xs text-ink-500 font-sans mb-2">{book.author}</p>
        <StarRating rating={book.ratings} size={11} showCount count={book.numReviews} />

        <div className="flex items-end justify-between mt-3 pt-3 border-t border-ink-100">
          <div>
            <span className="font-display font-bold text-base text-ink-900">{formatPrice(book.price)}</span>
            {book.originalPrice > book.price && (
              <span className="text-xs text-ink-400 line-through font-sans ml-1">{formatPrice(book.originalPrice)}</span>
            )}
          </div>
          <button
            onClick={() => addToCart(book._id)}
            className="w-8 h-8 rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-500 hover:text-white transition-all flex items-center justify-center"
            disabled={book.stock === 0}
            title="Add to Cart"
          >
            <ShoppingCart size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── LoadingSpinner ────────────────────────────────────────────────────────────
export function LoadingSpinner({ size = 'md', className = '' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <div className={`${sizes[size]} border-2 border-ink-200 border-t-brand-500 rounded-full animate-spin`} />
    </div>
  );
}

// ── PageLoader ────────────────────────────────────────────────────────────────
export function PageLoader() {
  return (
    <div className="fixed inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="flex flex-col items-center gap-3">
        <LoadingSpinner size="lg" />
        <p className="text-sm text-ink-500 font-sans animate-pulse">Loading...</p>
      </div>
    </div>
  );
}

// ── EmptyState ────────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      {icon && <div className="text-5xl mb-4">{icon}</div>}
      <h3 className="font-display font-semibold text-xl text-ink-700 mb-2">{title}</h3>
      {description && <p className="text-sm text-ink-500 font-sans max-w-sm mb-6">{description}</p>}
      {action}
    </div>
  );
}

// ── Breadcrumb ────────────────────────────────────────────────────────────────
export function Breadcrumb({ items }) {
  return (
    <nav className="flex items-center gap-1 text-sm font-sans text-ink-500 mb-6">
      {items.map((item, i) => (
        <span key={i} className="flex items-center gap-1">
          {i > 0 && <span className="text-ink-300">/</span>}
          {item.to ? (
            <Link to={item.to} className="hover:text-brand-600 transition-colors">{item.label}</Link>
          ) : (
            <span className="text-ink-700 font-medium">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

// ── Pagination ────────────────────────────────────────────────────────────────
export function Pagination({ pagination, onPageChange }) {
  if (!pagination || pagination.pages <= 1) return null;
  const { page, pages } = pagination;

  const pages_arr = Array.from({ length: Math.min(pages, 5) }, (_, i) => {
    if (pages <= 5) return i + 1;
    if (page <= 3) return i + 1;
    if (page >= pages - 2) return pages - 4 + i;
    return page - 2 + i;
  });

  return (
    <div className="flex items-center justify-center gap-1 mt-8">
      <button onClick={() => onPageChange(page - 1)} disabled={page === 1} className="w-9 h-9 rounded-lg flex items-center justify-center text-sm font-sans border border-ink-200 hover:border-brand-400 hover:text-brand-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all">‹</button>
      {pages_arr.map(p => (
        <button key={p} onClick={() => onPageChange(p)}
          className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-sans border transition-all ${
            p === page ? 'bg-brand-500 text-white border-brand-500' : 'border-ink-200 hover:border-brand-400 hover:text-brand-600'
          }`}
        >{p}</button>
      ))}
      <button onClick={() => onPageChange(page + 1)} disabled={page === pages} className="w-9 h-9 rounded-lg flex items-center justify-center text-sm font-sans border border-ink-200 hover:border-brand-400 hover:text-brand-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all">›</button>
    </div>
  );
}

// ── BookCardSkeleton ──────────────────────────────────────────────────────────
export function BookCardSkeleton() {
  return (
    <div className="card overflow-hidden">
      <div className="skeleton aspect-[3/4]" />
      <div className="p-4 space-y-2">
        <div className="skeleton h-3 w-16 rounded" />
        <div className="skeleton h-4 rounded" />
        <div className="skeleton h-3 w-3/4 rounded" />
        <div className="skeleton h-3 w-24 rounded mt-3" />
        <div className="flex justify-between items-center mt-3 pt-3 border-t border-ink-100">
          <div className="skeleton h-5 w-20 rounded" />
          <div className="skeleton w-8 h-8 rounded-lg" />
        </div>
      </div>
    </div>
  );
}

// ── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ isOpen, onClose, title, children, size = 'md' }) {
  if (!isOpen) return null;
  const sizes = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ink-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-white rounded-2xl shadow-2xl w-full ${sizes[size]} max-h-[90vh] overflow-y-auto animate-[fadeSlideIn_0.2s_ease-out]`}>
        {title && (
          <div className="flex items-center justify-between p-6 border-b border-ink-100">
            <h2 className="font-display font-bold text-xl text-ink-900">{title}</h2>
            <button onClick={onClose} className="btn-ghost p-1.5 text-ink-500 hover:text-ink-900"><X size={18} /></button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

// ── Badge component ───────────────────────────────────────────────────────────
export function StatusBadge({ status }) {
  const { statusColor } = require('../../utils/helpers');
  return <span className={`badge ${statusColor(status)}`}>{status}</span>;
}
