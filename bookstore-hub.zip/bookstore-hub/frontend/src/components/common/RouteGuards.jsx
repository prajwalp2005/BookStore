import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { PageLoader } from '../components/common/index.jsx';

export function ProtectedRoute({ children, roles }) {
  const { user, initializing } = useAuth();
  const location = useLocation();

  if (initializing) return <PageLoader />;

  if (!user) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
}

export function PublicOnlyRoute({ children }) {
  const { user, initializing } = useAuth();

  if (initializing) return <PageLoader />;

  if (user) {
    const dest = user.role === 'admin' ? '/admin' : user.role === 'seller' ? '/seller' : '/';
    return <Navigate to={dest} replace />;
  }

  return children;
}
