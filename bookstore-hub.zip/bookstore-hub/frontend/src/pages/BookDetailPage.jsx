import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Heart, Star, Package, Truck, Shield, Share2, ChevronLeft, ChevronRight } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, timeAgo, bookFallback, statusColor } from '../utils/helpers';
import { StarRating, BookCard, BookCardSkeleton, LoadingSpinner, Breadcrumb } from '../components/common/index.jsx';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function BookDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const [book, setBook] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeImg, setActiveImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: '', comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);
  const [activeTab, setActiveTab] = useState('description');

  useEffect(() => {
    window.scrollTo(0, 0);
    const fetchAll = async () => {
      setLoading(true);
      try {
        const [bookRes, revRes, recRes] = await Promise.all([
          api.get(`/books/${id}`),
          api.get(`/store/reviews/${id}`),
          api.get(`/books/${id}/recommendations`),
        ]);
        setBook(bookRes.data.book);
        setReviews(revRes.data.reviews);
        setRecommendations(recRes.data.books);
      } catch (_) { }
      setLoading(false);
    };
    fetchAll();
  }, [id]);

  const handleAddToCart = () => addToCart(book._id, qty);

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!user) { toast.error('Please login to write a review'); return; }
    setSubmittingReview(true);
    try {
      const res = await api.post('/store/reviews', { bookId: id, ...reviewForm });
      setReviews(prev => [res.data.review, ...prev]);
      setReviewForm({ rating: 5, title: '', comment: '' });
      toast.success('Review submitted!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit review');
    }
    setSubmittingReview(false);
  };

  if (loading) return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex items-center justify-center h-64"><LoadingSpinner size="lg" /></div>
    </div>
  );
  if (!book) return (
    <div className="max-w-7xl mx-auto px-6 py-12 text-center">
      <h2 className="font-display font-bold text-2xl text-ink-700">Book not found</h2>
      <Link to="/books" className="btn-primary mt-4 inline-block">Browse Books</Link>
    </div>
  );

  const inWishlist = isInWishlist(book._id);
  const images = book.images?.length ? book.images : [{ url: bookFallback(book.title) }];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <Breadcrumb items={[{ label: 'Home', to: '/' }, { label: 'Books', to: '/books' }, { label: book.category, to: `/books?category=${book.category}` }, { label: book.title }]} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
        {/* Images */}
        <div>
          <div className="relative aspect-[3/4] max-w-sm mx-auto bg-ink-100 rounded-2xl overflow-hidden shadow-book">
            <img src={images[activeImg]?.url} alt={book.title} className="w-full h-full object-cover"
              onError={e => { e.target.src = bookFallback(book.title); }} />
            {images.length > 1 && (
              <>
                <button onClick={() => setActiveImg(i => (i - 1 + images.length) % images.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center shadow hover:bg-white">
                  <ChevronLeft size={16} />
                </button>
                <button onClick={() => setActiveImg(i => (i + 1) % images.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center shadow hover:bg-white">
                  <ChevronRight size={16} />
                </button>
              </>
            )}
          </div>
          {images.length > 1 && (
            <div className="flex gap-2 justify-center mt-3">
              {images.map((img, i) => (
                <button key={i} onClick={() => setActiveImg(i)}
                  className={`w-14 h-18 rounded-lg overflow-hidden border-2 transition-all ${i === activeImg ? 'border-brand-500' : 'border-ink-200'}`}>
                  <img src={img.url} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <Link to={`/books?category=${book.category}`}
                className="badge bg-brand-100 text-brand-700 mb-2">{book.category}</Link>
              <h1 className="font-display font-black text-3xl text-ink-900 leading-tight">{book.title}</h1>
              <p className="text-ink-500 font-sans mt-1">by <span className="font-semibold text-ink-700">{book.author}</span></p>
            </div>
            <button onClick={() => toggleWishlist(book._id)}
              className={`w-10 h-10 rounded-xl flex items-center justify-center border-2 transition-all flex-shrink-0 ${inWishlist ? 'bg-red-500 border-red-500 text-white' : 'border-ink-200 text-ink-400 hover:border-red-400 hover:text-red-500'}`}>
              <Heart size={18} fill={inWishlist ? 'currentColor' : 'none'} />
            </button>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-3 mb-5">
            <StarRating rating={book.ratings} size={16} />
            <span className="font-sans font-bold text-ink-900">{Number(book.ratings).toFixed(1)}</span>
            <span className="text-ink-400 font-sans text-sm">({book.numReviews?.toLocaleString()} reviews)</span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 mb-5">
            <span className="font-display font-black text-4xl text-ink-900">{formatPrice(book.price)}</span>
            {book.originalPrice > book.price && (
              <>
                <span className="text-xl text-ink-400 line-through font-sans">{formatPrice(book.originalPrice)}</span>
                <span className="badge bg-green-100 text-green-700 text-sm">
                  {Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100)}% OFF
                </span>
              </>
            )}
          </div>

          {/* Stock status */}
          <div className="flex items-center gap-2 mb-5">
            <div className={`w-2 h-2 rounded-full ${book.stock > 0 ? 'bg-green-500' : 'bg-red-500'}`} />
            <span className={`text-sm font-sans font-medium ${book.stock > 0 ? 'text-green-700' : 'text-red-700'}`}>
              {book.stock > 10 ? 'In Stock' : book.stock > 0 ? `Only ${book.stock} left!` : 'Out of Stock'}
            </span>
          </div>

          {/* Quantity & CTA */}
          {book.stock > 0 && (
            <div className="flex items-center gap-3 mb-5">
              <div className="flex items-center border border-ink-200 rounded-lg overflow-hidden">
                <button onClick={() => setQty(q => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center hover:bg-ink-50 transition-colors font-bold">−</button>
                <span className="w-10 text-center font-sans font-semibold">{qty}</span>
                <button onClick={() => setQty(q => Math.min(book.stock, q + 1))} className="w-10 h-10 flex items-center justify-center hover:bg-ink-50 transition-colors font-bold">+</button>
              </div>
              <button onClick={handleAddToCart} className="btn-primary flex items-center gap-2 flex-1 justify-center text-base py-3">
                <ShoppingCart size={18} /> Add to Cart
              </button>
            </div>
          )}

          {/* Info pills */}
          <div className="grid grid-cols-3 gap-3 mb-6 py-5 border-y border-ink-100">
            <div className="text-center">
              <Truck size={20} className="mx-auto text-brand-500 mb-1" />
              <p className="text-xs font-sans text-ink-600">Free Delivery<br /><span className="text-ink-400">over ₹500</span></p>
            </div>
            <div className="text-center">
              <Package size={20} className="mx-auto text-brand-500 mb-1" />
              <p className="text-xs font-sans text-ink-600">Easy Returns<br /><span className="text-ink-400">within 7 days</span></p>
            </div>
            <div className="text-center">
              <Shield size={20} className="mx-auto text-brand-500 mb-1" />
              <p className="text-xs font-sans text-ink-600">Secure Payment<br /><span className="text-ink-400">100% Safe</span></p>
            </div>
          </div>

          {/* Meta */}
          <div className="space-y-2 text-sm font-sans">
            {book.publisher && <div className="flex gap-2"><span className="text-ink-500 w-28">Publisher</span><span className="text-ink-800 font-medium">{book.publisher}</span></div>}
            {book.language && <div className="flex gap-2"><span className="text-ink-500 w-28">Language</span><span className="text-ink-800 font-medium">{book.language}</span></div>}
            {book.pages && <div className="flex gap-2"><span className="text-ink-500 w-28">Pages</span><span className="text-ink-800 font-medium">{book.pages}</span></div>}
            {book.isbn && <div className="flex gap-2"><span className="text-ink-500 w-28">ISBN</span><span className="text-ink-800 font-medium">{book.isbn}</span></div>}
            {book.sellerId?.storeName && <div className="flex gap-2"><span className="text-ink-500 w-28">Sold by</span><span className="text-brand-600 font-medium">{book.sellerId.storeName}</span></div>}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-10">
        <div className="flex gap-1 border-b border-ink-200 mb-6">
          {['description', 'reviews'].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`px-5 py-2.5 text-sm font-sans font-semibold capitalize border-b-2 transition-all -mb-px ${
                activeTab === tab ? 'border-brand-500 text-brand-600' : 'border-transparent text-ink-500 hover:text-ink-800'
              }`}
            >{tab} {tab === 'reviews' && `(${reviews.length})`}</button>
          ))}
        </div>

        {activeTab === 'description' && (
          <div className="prose max-w-none font-body text-ink-700 leading-relaxed">
            <p>{book.description}</p>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-6">
            {/* Review form */}
            {user && (
              <div className="card p-6">
                <h3 className="font-display font-bold text-lg mb-4">Write a Review</h3>
                <form onSubmit={handleSubmitReview} className="space-y-4">
                  <div>
                    <label className="label">Rating</label>
                    <div className="flex gap-1">
                      {[1,2,3,4,5].map(r => (
                        <button key={r} type="button" onClick={() => setReviewForm(f => ({...f, rating: r}))}
                          className="p-1 transition-transform hover:scale-110">
                          <Star size={24} className={r <= reviewForm.rating ? 'star-filled' : 'star-empty'} fill={r <= reviewForm.rating ? 'currentColor' : 'none'} />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="label">Review Title</label>
                    <input value={reviewForm.title} onChange={e => setReviewForm(f => ({...f, title: e.target.value}))}
                      placeholder="Summarize your review" className="input" />
                  </div>
                  <div>
                    <label className="label">Review</label>
                    <textarea value={reviewForm.comment} onChange={e => setReviewForm(f => ({...f, comment: e.target.value}))}
                      placeholder="Share your experience with this book..." rows={4} required className="input resize-none" />
                  </div>
                  <button type="submit" disabled={submittingReview} className="btn-primary">
                    {submittingReview ? 'Submitting...' : 'Submit Review'}
                  </button>
                </form>
              </div>
            )}

            {/* Reviews list */}
            {reviews.length === 0 ? (
              <div className="text-center py-10 text-ink-500 font-sans">No reviews yet. Be the first to review!</div>
            ) : (
              reviews.map(review => (
                <div key={review._id} className="card p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-brand-100 flex items-center justify-center">
                        {review.user?.avatar
                          ? <img src={review.user.avatar} alt="" className="w-full h-full rounded-full object-cover" />
                          : <span className="font-bold text-brand-700 text-sm">{review.user?.name?.[0] || 'U'}</span>
                        }
                      </div>
                      <div>
                        <p className="font-sans font-semibold text-sm text-ink-900">{review.user?.name}</p>
                        <p className="text-xs text-ink-400 font-sans">{timeAgo(review.createdAt)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <StarRating rating={review.rating} size={13} />
                      {review.isVerifiedPurchase && <span className="badge bg-green-100 text-green-700 text-[10px]">✓ Verified</span>}
                    </div>
                  </div>
                  {review.title && <h4 className="font-sans font-semibold text-sm text-ink-800 mb-1">{review.title}</h4>}
                  <p className="text-sm text-ink-600 font-sans leading-relaxed">{review.comment}</p>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <div>
          <h2 className="section-title mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {recommendations.map(b => <BookCard key={b._id} book={b} />)}
          </div>
        </div>
      )}
    </div>
  );
}
