import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Search, Star, TrendingUp, Shield, Truck, RefreshCw } from 'lucide-react';
import api from '../utils/api';
import { CATEGORIES, formatPrice } from '../utils/helpers';
import { BookCard, BookCardSkeleton, StarRating } from '../components/common/index.jsx';

export default function HomePage() {
  const navigate = useNavigate();
  const [featured, setFeatured] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [featRes, newRes, topRes] = await Promise.all([
          api.get('/books?featured=true&limit=8'),
          api.get('/books?sort=newest&limit=8'),
          api.get('/books?sort=rating&limit=4'),
        ]);
        setFeatured(featRes.data.books);
        setNewArrivals(newRes.data.books);
        setTopRated(topRes.data.books);
      } catch (_) {}
      setLoading(false);
    };
    fetchData();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate(`/books?search=${encodeURIComponent(searchQuery.trim())}`);
  };

  return (
    <div className="page-enter">
      {/* ── Hero ── */}
      <section className="relative overflow-hidden bg-ink-950 text-white">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.03\"%3E%3Cpath d=\"M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]" />
        <div className="absolute inset-0 bg-gradient-to-br from-brand-900/40 via-transparent to-ink-900/60" />

        <div className="relative max-w-7xl mx-auto px-6 py-20 md:py-28 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-2 bg-brand-500/20 text-brand-300 border border-brand-500/30 rounded-full px-4 py-1.5 text-xs font-sans font-semibold mb-6">
              <Star size={12} fill="currentColor" /> Over 10,000+ Books Available
            </div>
            <h1 className="font-display font-black text-4xl md:text-6xl leading-tight mb-6">
              Discover Your<br />
              <span className="text-brand-400">Next Great</span><br />
              Read
            </h1>
            <p className="text-ink-400 font-sans text-lg leading-relaxed max-w-lg mb-8">
              Browse thousands of books across every genre. From bestsellers to rare finds — your perfect book is waiting.
            </p>

            {/* Hero Search */}
            <form onSubmit={handleSearch} className="flex max-w-md mx-auto md:mx-0 mb-8">
              <div className="flex-1 relative">
                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-500" />
                <input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Title, author, or genre..."
                  className="w-full pl-11 pr-4 py-3 rounded-l-xl bg-white/10 border border-white/20 text-white placeholder-ink-400 font-sans text-sm focus:outline-none focus:bg-white/15 focus:border-brand-400 transition-all"
                />
              </div>
              <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-white px-6 py-3 rounded-r-xl font-sans font-semibold text-sm transition-colors">
                Search
              </button>
            </form>

            <div className="flex items-center gap-6 justify-center md:justify-start text-xs text-ink-400 font-sans">
              <span>🔥 Trending: Fantasy, Sci-Fi, Self-Help</span>
              <span>📦 Free shipping over ₹500</span>
            </div>
          </div>

          {/* Featured book stack */}
          <div className="flex-shrink-0 relative w-64 h-72 hidden lg:block">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="absolute rounded-2xl overflow-hidden shadow-2xl border border-white/10"
                style={{ width: 160, height: 220, top: i * 12, left: i * 16, transform: `rotate(${(i - 1) * 4}deg)`, zIndex: 3 - i }}>
                {featured[i] && (
                  <img src={featured[i].images?.[0]?.url} alt="" className="w-full h-full object-cover" onError={e => e.target.style.display='none'} />
                )}
                {!featured[i] && <div className="w-full h-full bg-gradient-to-br from-brand-700 to-ink-800" />}
              </div>
            ))}
          </div>
        </div>

        {/* Stats bar */}
        <div className="relative border-t border-white/10">
          <div className="max-w-7xl mx-auto px-6 py-5 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            {[
              { label: 'Books Available', value: '10,000+' },
              { label: 'Happy Readers', value: '50,000+' },
              { label: 'Categories', value: '15+' },
              { label: 'Daily Orders', value: '500+' },
            ].map(({ label, value }) => (
              <div key={label}>
                <div className="font-display font-black text-2xl text-white">{value}</div>
                <div className="text-xs text-ink-400 font-sans mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features Strip ── */}
      <section className="bg-brand-500 text-white">
        <div className="max-w-7xl mx-auto px-6 py-4 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { icon: Truck, text: 'Free Delivery over ₹500' },
            { icon: RefreshCw, text: '7-Day Easy Returns' },
            { icon: Shield, text: 'Secure Payments' },
            { icon: Star, text: 'Curated Collections' },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-2.5 justify-center">
              <Icon size={16} />
              <span className="text-xs font-sans font-semibold">{text}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── Categories ── */}
      <section className="max-w-7xl mx-auto px-6 py-14">
        <div className="flex items-center justify-between mb-8">
          <h2 className="section-title">Browse by Category</h2>
          <Link to="/books" className="text-sm text-brand-600 font-sans font-medium hover:text-brand-700 flex items-center gap-1">
            View All <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-8 gap-3">
          {CATEGORIES.slice(0, 8).map(({ name, icon, color }) => (
            <Link key={name} to={`/books?category=${name}`}
              className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white border border-ink-100 hover:border-brand-300 hover:shadow-md transition-all group text-center"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform`}>
                {icon}
              </div>
              <span className="text-xs font-sans font-semibold text-ink-600 group-hover:text-brand-600 transition-colors">{name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Featured Books ── */}
      <section className="bg-ink-50 py-14">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-title">Featured Books</h2>
              <p className="text-ink-500 font-sans text-sm mt-1">Handpicked by our editors</p>
            </div>
            <Link to="/books?featured=true" className="btn-secondary text-sm px-4 py-2 flex items-center gap-1.5">
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4 md:gap-5">
            {loading
              ? Array(8).fill(0).map((_, i) => <BookCardSkeleton key={i} />)
              : featured.slice(0, 8).map(book => <BookCard key={book._id} book={book} />)
            }
          </div>
        </div>
      </section>

      {/* ── Promo Banner ── */}
      <section className="max-w-7xl mx-auto px-6 py-10">
        <div className="rounded-3xl bg-gradient-to-r from-brand-600 to-brand-800 overflow-hidden relative p-8 md:p-12 text-white">
          <div className="absolute right-0 top-0 w-64 h-full opacity-10 flex items-center justify-end pr-8">
            <span className="font-display text-[10rem] font-black leading-none">📚</span>
          </div>
          <div className="relative max-w-lg">
            <span className="badge bg-white/20 text-white border-white/30 mb-4">Limited Time Offer</span>
            <h3 className="font-display font-black text-3xl md:text-4xl mb-3">Get 20% Off Your First Order</h3>
            <p className="font-sans text-brand-100 mb-6 leading-relaxed">Join thousands of readers who discover amazing books every day. New members get exclusive discount on their first purchase.</p>
            <Link to="/register" className="inline-flex items-center gap-2 bg-white text-brand-700 font-sans font-bold px-6 py-3 rounded-xl hover:bg-brand-50 transition-colors">
              Get Started Free <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── New Arrivals ── */}
      <section className="max-w-7xl mx-auto px-6 pb-14">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="section-title">New Arrivals</h2>
            <p className="text-ink-500 font-sans text-sm mt-1">Fresh titles just added</p>
          </div>
          <Link to="/books?sort=newest" className="btn-secondary text-sm px-4 py-2 flex items-center gap-1.5">
            View All <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-5">
          {loading
            ? Array(8).fill(0).map((_, i) => <BookCardSkeleton key={i} />)
            : newArrivals.slice(0, 8).map(book => <BookCard key={book._id} book={book} />)
          }
        </div>
      </section>

      {/* ── Top Rated ── */}
      {topRated.length > 0 && (
        <section className="bg-ink-950 text-white py-14">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp size={24} className="text-brand-400" />
              <h2 className="font-display font-bold text-2xl md:text-3xl">Bestsellers & Top Rated</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {topRated.map((book, i) => (
                <Link key={book._id} to={`/books/${book._id}`}
                  className="flex gap-4 bg-ink-900 rounded-2xl p-4 hover:bg-ink-800 transition-colors group">
                  <div className="flex-shrink-0 w-16 h-20 rounded-lg overflow-hidden">
                    <img src={book.images?.[0]?.url || ''} alt={book.title} className="w-full h-full object-cover" onError={e => e.target.src = `https://ui-avatars.com/api/?name=${book.title}&background=e35d18&color=fff&size=100`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-display font-semibold text-white group-hover:text-brand-300 transition-colors line-clamp-1">{book.title}</h4>
                        <p className="text-xs text-ink-400 font-sans">{book.author}</p>
                      </div>
                      <span className="text-2xl font-display font-black text-ink-600">#{i + 1}</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <StarRating rating={book.ratings} size={12} showCount count={book.numReviews} />
                      <span className="font-display font-bold text-brand-400">{formatPrice(book.price)}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
