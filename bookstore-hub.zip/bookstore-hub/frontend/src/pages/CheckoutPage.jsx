import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck, CheckCircle, Lock } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { formatPrice, bookFallback } from '../utils/helpers';
import toast from 'react-hot-toast';

const STEPS = ['Shipping', 'Payment', 'Review'];

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { cart, cartTotal, clearCart } = useCart();
  const [step, setStep] = useState(0);
  const [placing, setPlacing] = useState(false);

  const [address, setAddress] = useState({
    name: user?.name || '', phone: user?.phone || '',
    street: '', city: '', state: '', pincode: '', country: 'India',
  });
  const [payment, setPayment] = useState({ method: 'cod', cardNumber: '', expiry: '', cvv: '' });

  const items = cart?.items || [];
  const shipping = cartTotal > 500 ? 0 : 50;
  const finalTotal = cartTotal + shipping;

  const handlePlaceOrder = async () => {
    setPlacing(true);
    try {
      const orderRes = await api.post('/orders', {
        items: items.map(i => ({ bookId: i.book._id, quantity: i.quantity })),
        shippingAddress: address,
        paymentMethod: payment.method,
      });

      const orderId = orderRes.data.order._id;

      if (payment.method === 'cod') {
        await api.post('/payments/cod', { orderId });
      } else {
        // Mock card payment
        const piRes = await api.post('/payments/create-intent', { orderId });
        await api.post('/payments/confirm', { orderId, paymentIntentId: piRes.data.paymentIntentId });
      }

      toast.success('🎉 Order placed successfully!');
      navigate(`/orders/${orderId}`, { state: { newOrder: true } });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
    }
    setPlacing(false);
  };

  const isAddressValid = address.name && address.phone && address.street && address.city && address.state && address.pincode;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <h1 className="font-display font-bold text-3xl text-ink-900 mb-8">Checkout</h1>

      {/* Progress steps */}
      <div className="flex items-center justify-center gap-0 mb-10">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-sans font-semibold transition-all ${
              i === step ? 'bg-brand-500 text-white shadow-md' :
              i < step ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-400'
            }`}>
              {i < step ? <CheckCircle size={15} /> : <span>{i + 1}</span>}
              {s}
            </div>
            {i < STEPS.length - 1 && <div className={`w-12 h-0.5 ${i < step ? 'bg-green-400' : 'bg-ink-200'}`} />}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="lg:col-span-2">
          {step === 0 && (
            <div className="card p-6">
              <h2 className="font-display font-bold text-xl mb-5 flex items-center gap-2"><Truck size={20} className="text-brand-500" /> Shipping Address</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label">Full Name *</label>
                  <input value={address.name} onChange={e => setAddress(a => ({...a, name: e.target.value}))} className="input" placeholder="Your full name" required />
                </div>
                <div>
                  <label className="label">Phone Number *</label>
                  <input value={address.phone} onChange={e => setAddress(a => ({...a, phone: e.target.value}))} className="input" placeholder="+91 XXXXX XXXXX" required />
                </div>
                <div className="sm:col-span-2">
                  <label className="label">Street Address *</label>
                  <input value={address.street} onChange={e => setAddress(a => ({...a, street: e.target.value}))} className="input" placeholder="House/Flat no., Street, Area" required />
                </div>
                <div>
                  <label className="label">City *</label>
                  <input value={address.city} onChange={e => setAddress(a => ({...a, city: e.target.value}))} className="input" placeholder="City" required />
                </div>
                <div>
                  <label className="label">State *</label>
                  <input value={address.state} onChange={e => setAddress(a => ({...a, state: e.target.value}))} className="input" placeholder="State" required />
                </div>
                <div>
                  <label className="label">PIN Code *</label>
                  <input value={address.pincode} onChange={e => setAddress(a => ({...a, pincode: e.target.value}))} className="input" placeholder="6-digit PIN code" required />
                </div>
                <div>
                  <label className="label">Country</label>
                  <input value={address.country} readOnly className="input bg-ink-50 cursor-not-allowed" />
                </div>
              </div>
              <button onClick={() => setStep(1)} disabled={!isAddressValid}
                className="btn-primary mt-6 px-8 disabled:opacity-60">Continue to Payment</button>
            </div>
          )}

          {step === 1 && (
            <div className="card p-6">
              <h2 className="font-display font-bold text-xl mb-5 flex items-center gap-2"><CreditCard size={20} className="text-brand-500" /> Payment Method</h2>
              <div className="space-y-3">
                {[
                  { value: 'cod', label: 'Cash on Delivery', icon: '💰', desc: 'Pay when your order arrives' },
                  { value: 'card', label: 'Credit / Debit Card', icon: '💳', desc: 'Visa, Mastercard, RuPay' },
                  { value: 'upi', label: 'UPI Payment', icon: '📱', desc: 'PhonePe, GPay, Paytm' },
                ].map(opt => (
                  <label key={opt.value} className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    payment.method === opt.value ? 'border-brand-500 bg-brand-50' : 'border-ink-200 hover:border-ink-300'
                  }`}>
                    <input type="radio" value={opt.value} checked={payment.method === opt.value}
                      onChange={e => setPayment(p => ({...p, method: e.target.value}))}
                      className="accent-brand-500" />
                    <span className="text-2xl">{opt.icon}</span>
                    <div>
                      <p className="font-sans font-semibold text-sm text-ink-900">{opt.label}</p>
                      <p className="text-xs text-ink-500 font-sans">{opt.desc}</p>
                    </div>
                  </label>
                ))}
              </div>

              {payment.method === 'card' && (
                <div className="mt-5 p-4 bg-ink-50 rounded-xl space-y-3">
                  <div>
                    <label className="label">Card Number</label>
                    <input value={payment.cardNumber} onChange={e => setPayment(p => ({...p, cardNumber: e.target.value}))}
                      placeholder="1234 5678 9012 3456" maxLength={19} className="input font-mono" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Expiry</label>
                      <input value={payment.expiry} onChange={e => setPayment(p => ({...p, expiry: e.target.value}))}
                        placeholder="MM/YY" maxLength={5} className="input font-mono" />
                    </div>
                    <div>
                      <label className="label">CVV</label>
                      <input value={payment.cvv} onChange={e => setPayment(p => ({...p, cvv: e.target.value}))}
                        placeholder="•••" maxLength={3} type="password" className="input font-mono" />
                    </div>
                  </div>
                  <p className="text-xs text-ink-400 font-sans flex items-center gap-1.5"><Lock size={11} /> Your card details are encrypted and secure.</p>
                </div>
              )}

              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(0)} className="btn-secondary px-6">Back</button>
                <button onClick={() => setStep(2)} className="btn-primary px-8">Review Order</button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="card p-6">
              <h2 className="font-display font-bold text-xl mb-5">Review Your Order</h2>

              {/* Address summary */}
              <div className="bg-ink-50 rounded-xl p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-sans font-semibold text-sm text-ink-800">Delivering to</p>
                  <button onClick={() => setStep(0)} className="text-xs text-brand-600 font-sans font-medium">Edit</button>
                </div>
                <p className="text-sm text-ink-600 font-sans">{address.name} • {address.phone}</p>
                <p className="text-sm text-ink-600 font-sans">{address.street}, {address.city}, {address.state} - {address.pincode}</p>
              </div>

              {/* Payment summary */}
              <div className="bg-ink-50 rounded-xl p-4 mb-5">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-sans font-semibold text-sm text-ink-800">Payment</p>
                  <button onClick={() => setStep(1)} className="text-xs text-brand-600 font-sans font-medium">Edit</button>
                </div>
                <p className="text-sm text-ink-600 font-sans capitalize">
                  {payment.method === 'cod' ? '💰 Cash on Delivery' : payment.method === 'card' ? '💳 Credit/Debit Card' : '📱 UPI'}
                </p>
              </div>

              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="btn-secondary px-6">Back</button>
                <button onClick={handlePlaceOrder} disabled={placing}
                  className="btn-primary flex-1 flex items-center justify-center gap-2 py-3.5 text-base">
                  {placing ? (
                    <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />Placing Order...</>
                  ) : (
                    <>Place Order • {formatPrice(finalTotal)}</>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Order summary sidebar */}
        <div>
          <div className="card p-5 sticky top-24">
            <h3 className="font-display font-bold text-base mb-4">Order Items ({items.length})</h3>
            <div className="space-y-3 mb-4 max-h-64 overflow-y-auto pr-1">
              {items.map(item => {
                const book = item.book;
                if (!book) return null;
                return (
                  <div key={book._id} className="flex gap-3">
                    <div className="w-10 h-14 rounded-lg overflow-hidden bg-ink-100 flex-shrink-0">
                      <img src={book.images?.[0]?.url || bookFallback(book.title)} alt={book.title}
                        className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-sans font-semibold text-ink-800 line-clamp-2 leading-snug">{book.title}</p>
                      <p className="text-xs text-ink-400 font-sans">Qty: {item.quantity}</p>
                      <p className="text-xs font-display font-bold text-ink-800">{formatPrice(book.price * item.quantity)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="border-t border-ink-100 pt-3 space-y-2 text-sm font-sans">
              <div className="flex justify-between text-ink-600">
                <span>Subtotal</span><span className="font-medium">{formatPrice(cartTotal)}</span>
              </div>
              <div className="flex justify-between text-ink-600">
                <span>Shipping</span>
                {shipping === 0 ? <span className="text-green-600 font-semibold">FREE</span> : <span className="font-medium">{formatPrice(shipping)}</span>}
              </div>
              <div className="flex justify-between font-bold text-ink-900 text-base pt-1 border-t border-ink-100">
                <span>Total</span><span className="font-display font-black">{formatPrice(finalTotal)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
