import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, ShoppingBag, TrendingUp, Plus, Edit, Trash2, Package } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, statusColor, CATEGORIES } from '../../utils/helpers';
import { LoadingSpinner, Pagination, StarRating } from '../../components/common/index.jsx';
import toast from 'react-hot-toast';

export default function SellerDashboard() {
  const [activeSection, setActiveSection] = useState('books');
  const [books, setBooks] = useState([]);
  const [orders, setOrders] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editBook, setEditBook] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    title: '', author: '', description: '', category: 'Fiction',
    price: '', originalPrice: '', stock: '', pages: '', publisher: '',
    language: 'English', isbn: '', tags: '', isFeatured: false,
  });

  const fetchBooks = async (page = 1) => {
    setLoading(true);
    try {
      const r = await api.get(`/books/seller/mine?page=${page}&limit=10`);
      setBooks(r.data.books); setPagination(p => ({...p, books: r.data.pagination}));
    } catch (_) {}
    setLoading(false);
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const r = await api.get('/orders/seller/mine');
      setOrders(r.data.orders);
    } catch (_) {}
    setLoading(false);
  };

  useEffect(() => {
    if (activeSection === 'books') fetchBooks();
    if (activeSection === 'orders') fetchOrders();
  }, [activeSection]);

  const resetForm = () => {
    setForm({ title: '', author: '', description: '', category: 'Fiction', price: '', originalPrice: '', stock: '', pages: '', publisher: '', language: 'English', isbn: '', tags: '', isFeatured: false });
    setEditBook(null);
    setShowForm(false);
  };

  const openEdit = (book) => {
    setEditBook(book);
    setForm({
      title: book.title, author: book.author, description: book.description, category: book.category,
      price: book.price, originalPrice: book.originalPrice || '', stock: book.stock,
      pages: book.pages || '', publisher: book.publisher || '', language: book.language || 'English',
      isbn: book.isbn || '', tags: book.tags?.join(', ') || '', isFeatured: book.isFeatured,
    });
    setShowForm(true);
    window.scrollTo(0, 0);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = { ...form, tags: form.tags.split(',').map(t => t.trim()).filter(Boolean) };
      if (editBook) {
        const res = await api.put(`/books/${editBook._id}`, payload);
        setBooks(bs => bs.map(b => b._id === editBook._id ? res.data.book : b));
        toast.success('Book updated!');
      } else {
        const res = await api.post('/books', payload);
        setBooks(bs => [res.data.book, ...bs]);
        toast.success('Book listed!');
      }
      resetForm();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save book');
    }
    setSubmitting(false);
  };

  const handleDelete = async (bookId) => {
    if (!window.confirm('Delete this book?')) return;
    try {
      await api.delete(`/books/${bookId}`);
      setBooks(bs => bs.filter(b => b._id !== bookId));
      toast.success('Book deleted');
    } catch (err) {
      toast.error('Failed to delete');
    }
  };

  const handleOrderStatus = async (orderId, status) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status });
      setOrders(os => os.map(o => o._id === orderId ? {...o, status} : o));
      toast.success('Status updated');
    } catch (_) { toast.error('Failed to update status'); }
  };

  const totalRevenue = orders.filter(o => o.paymentStatus === 'paid').reduce((s, o) => s + o.finalAmount, 0);

  return (
    <div className="flex min-h-screen bg-ink-50 page-enter">
      {/* Sidebar */}
      <aside className="w-56 bg-ink-950 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-5 border-b border-ink-800">
          <Link to="/" className="flex items-center gap-2 mb-2">
            <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
              <BookOpen size={15} className="text-white" />
            </div>
            <span className="font-display font-bold text-sm">BookStore Hub</span>
          </Link>
          <span className="badge bg-amber-500/20 text-amber-300 text-[10px]">Seller Panel</span>
        </div>
        <nav className="flex-1 p-3">
          {[
            { key: 'books', label: 'My Books', icon: BookOpen },
            { key: 'orders', label: 'Orders', icon: ShoppingBag },
          ].map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setActiveSection(key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-sans font-medium transition-all mb-1 ${
                activeSection === key ? 'bg-brand-500 text-white' : 'text-ink-400 hover:bg-ink-800 hover:text-white'
              }`}
            ><Icon size={16} />{label}</button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 overflow-auto p-6">
        {/* Mobile nav */}
        <div className="flex gap-2 mb-6 md:hidden">
          {[{ key: 'books', label: 'My Books' }, { key: 'orders', label: 'Orders' }].map(({ key, label }) => (
            <button key={key} onClick={() => setActiveSection(key)}
              className={`category-pill ${activeSection === key ? 'category-pill-active' : 'category-pill-inactive'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── Books ── */}
        {activeSection === 'books' && (
          <div>
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="card p-4"><p className="font-display font-black text-2xl text-ink-900">{books.length}</p><p className="text-xs text-ink-500 font-sans">Listed Books</p></div>
              <div className="card p-4"><p className="font-display font-black text-2xl text-ink-900">{orders.length || '—'}</p><p className="text-xs text-ink-500 font-sans">Total Orders</p></div>
              <div className="card p-4"><p className="font-display font-black text-2xl text-brand-600">{formatPrice(totalRevenue)}</p><p className="text-xs text-ink-500 font-sans">Revenue</p></div>
            </div>

            {/* Form */}
            {showForm ? (
              <div className="card p-6 mb-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-display font-bold text-xl">{editBook ? 'Edit Book' : 'List New Book'}</h2>
                  <button onClick={resetForm} className="btn-ghost text-sm">Cancel</button>
                </div>
                <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="label">Book Title *</label>
                    <input value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} required className="input" placeholder="Full book title" />
                  </div>
                  <div>
                    <label className="label">Author *</label>
                    <input value={form.author} onChange={e => setForm(f => ({...f, author: e.target.value}))} required className="input" />
                  </div>
                  <div>
                    <label className="label">Category *</label>
                    <select value={form.category} onChange={e => setForm(f => ({...f, category: e.target.value}))} required className="input">
                      {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="label">Description *</label>
                    <textarea value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} required rows={4} className="input resize-none" />
                  </div>
                  <div>
                    <label className="label">Selling Price (₹) *</label>
                    <input type="number" value={form.price} onChange={e => setForm(f => ({...f, price: e.target.value}))} required min="0" className="input" />
                  </div>
                  <div>
                    <label className="label">Original Price (₹)</label>
                    <input type="number" value={form.originalPrice} onChange={e => setForm(f => ({...f, originalPrice: e.target.value}))} min="0" className="input" />
                  </div>
                  <div>
                    <label className="label">Stock *</label>
                    <input type="number" value={form.stock} onChange={e => setForm(f => ({...f, stock: e.target.value}))} required min="0" className="input" />
                  </div>
                  <div>
                    <label className="label">Pages</label>
                    <input type="number" value={form.pages} onChange={e => setForm(f => ({...f, pages: e.target.value}))} min="0" className="input" />
                  </div>
                  <div>
                    <label className="label">Publisher</label>
                    <input value={form.publisher} onChange={e => setForm(f => ({...f, publisher: e.target.value}))} className="input" />
                  </div>
                  <div>
                    <label className="label">Language</label>
                    <input value={form.language} onChange={e => setForm(f => ({...f, language: e.target.value}))} className="input" />
                  </div>
                  <div>
                    <label className="label">ISBN</label>
                    <input value={form.isbn} onChange={e => setForm(f => ({...f, isbn: e.target.value}))} className="input" />
                  </div>
                  <div>
                    <label className="label">Tags (comma separated)</label>
                    <input value={form.tags} onChange={e => setForm(f => ({...f, tags: e.target.value}))} placeholder="e.g. classic, fiction, award-winning" className="input" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={form.isFeatured} onChange={e => setForm(f => ({...f, isFeatured: e.target.checked}))} className="accent-brand-500" />
                      <span className="text-sm font-sans text-ink-700">Mark as Featured</span>
                    </label>
                  </div>
                  <div className="sm:col-span-2 flex gap-3">
                    <button type="submit" disabled={submitting} className="btn-primary px-8">
                      {submitting ? 'Saving...' : editBook ? 'Update Book' : 'List Book'}
                    </button>
                    <button type="button" onClick={resetForm} className="btn-secondary">Cancel</button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="flex items-center justify-between mb-4">
                <h1 className="font-display font-bold text-2xl text-ink-900">My Books</h1>
                <button onClick={() => setShowForm(true)} className="btn-primary flex items-center gap-2">
                  <Plus size={16} /> Add New Book
                </button>
              </div>
            )}

            {/* Books table */}
            {loading ? <LoadingSpinner className="py-10" /> : (
              <div className="card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm font-sans">
                    <thead className="bg-ink-50 border-b border-ink-200">
                      <tr>
                        {['Book','Category','Price','Stock','Rating','Actions'].map(h => (
                          <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-ink-500 uppercase">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {books.length === 0 ? (
                        <tr><td colSpan={6} className="text-center py-10 text-ink-400 font-sans">No books listed yet. Add your first book!</td></tr>
                      ) : books.map(book => (
                        <tr key={book._id} className="border-b border-ink-50 hover:bg-ink-50">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-11 rounded-lg overflow-hidden bg-ink-100 flex-shrink-0">
                                <img src={book.images?.[0]?.url} alt="" className="w-full h-full object-cover" />
                              </div>
                              <div className="max-w-[180px]">
                                <p className="font-semibold text-ink-800 line-clamp-1">{book.title}</p>
                                <p className="text-xs text-ink-400">{book.author}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4"><span className="badge bg-ink-100 text-ink-600">{book.category}</span></td>
                          <td className="py-3 px-4 font-display font-bold">{formatPrice(book.price)}</td>
                          <td className="py-3 px-4">
                            <span className={`font-semibold ${book.stock === 0 ? 'text-red-600' : book.stock < 5 ? 'text-amber-600' : 'text-green-600'}`}>{book.stock}</span>
                          </td>
                          <td className="py-3 px-4"><StarRating rating={book.ratings} size={12} /></td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <button onClick={() => openEdit(book)} className="w-7 h-7 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 flex items-center justify-center transition-colors">
                                <Edit size={12} />
                              </button>
                              <button onClick={() => handleDelete(book._id)} className="w-7 h-7 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 flex items-center justify-center transition-colors">
                                <Trash2 size={12} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            <Pagination pagination={pagination.books} onPageChange={fetchBooks} />
          </div>
        )}

        {/* ── Orders ── */}
        {activeSection === 'orders' && (
          <div>
            <h1 className="font-display font-bold text-2xl text-ink-900 mb-6">Orders</h1>
            {loading ? <LoadingSpinner className="py-10" /> : (
              <div className="card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm font-sans">
                    <thead className="bg-ink-50 border-b border-ink-200">
                      <tr>
                        {['Order','Customer','Items','Amount','Status','Update'].map(h => (
                          <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-ink-500 uppercase">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {orders.length === 0 ? (
                        <tr><td colSpan={6} className="text-center py-10 text-ink-400 font-sans">No orders yet.</td></tr>
                      ) : orders.map(order => (
                        <tr key={order._id} className="border-b border-ink-50 hover:bg-ink-50">
                          <td className="py-3 px-4 font-mono text-xs text-brand-600">#{order._id.slice(-8).toUpperCase()}</td>
                          <td className="py-3 px-4">
                            <p className="font-semibold text-ink-800">{order.user?.name}</p>
                            <p className="text-xs text-ink-400">{formatDate(order.createdAt)}</p>
                          </td>
                          <td className="py-3 px-4 text-ink-600">{order.items.length} item{order.items.length > 1 ? 's' : ''}</td>
                          <td className="py-3 px-4 font-display font-bold">{formatPrice(order.finalAmount)}</td>
                          <td className="py-3 px-4"><span className={`badge ${statusColor(order.status)}`}>{order.status}</span></td>
                          <td className="py-3 px-4">
                            <select value={order.status} onChange={e => handleOrderStatus(order._id, e.target.value)}
                              className="input py-1.5 text-xs w-32">
                              {['Pending','Confirmed','Shipped','Delivered'].map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
