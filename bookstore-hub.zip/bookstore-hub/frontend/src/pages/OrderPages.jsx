import { useState, useEffect } from 'react';
import { Link, useParams, useLocation } from 'react-router-dom';
import { Package, CheckCircle, Truck, Clock, XCircle, RotateCcw, ChevronRight } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, statusColor, bookFallback } from '../utils/helpers';
import { LoadingSpinner, EmptyState, Pagination, Breadcrumb } from '../components/common/index.jsx';
import toast from 'react-hot-toast';

const statusIcons = {
  Pending:   <Clock size={16} className="text-amber-500" />,
  Confirmed: <CheckCircle size={16} className="text-blue-500" />,
  Shipped:   <Truck size={16} className="text-indigo-500" />,
  Delivered: <CheckCircle size={16} className="text-green-500" />,
  Cancelled: <XCircle size={16} className="text-red-500" />,
  Returned:  <RotateCcw size={16} className="text-gray-500" />,
};

// ── My Orders List ────────────────────────────────────────────────────────────
export function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams({ page, limit: 10 });
        if (statusFilter) params.set('status', statusFilter);
        const res = await api.get(`/orders/my?${params}`);
        setOrders(res.data.orders);
        setPagination(res.data.pagination);
      } catch (_) {}
      setLoading(false);
    };
    fetch();
  }, [page, statusFilter]);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <h1 className="font-display font-bold text-3xl text-ink-900 mb-6">My Orders</h1>

      {/* Status filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-1">
        {['', 'Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`category-pill flex-shrink-0 ${statusFilter === s ? 'category-pill-active' : 'category-pill-inactive'}`}>
            {s || 'All Orders'}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingSpinner className="py-16" />
      ) : orders.length === 0 ? (
        <EmptyState icon="📦" title="No orders yet" description="You haven't placed any orders yet. Start shopping!"
          action={<Link to="/books" className="btn-primary">Shop Now</Link>} />
      ) : (
        <>
          <div className="space-y-4">
            {orders.map(order => (
              <Link key={order._id} to={`/orders/${order._id}`}
                className="card p-5 flex items-center gap-4 hover:shadow-book-hover transition-all group">
                {/* Book covers */}
                <div className="flex -space-x-2 flex-shrink-0">
                  {order.items.slice(0, 3).map((item, i) => (
                    <div key={i} className="w-10 h-14 rounded-lg overflow-hidden bg-ink-100 border-2 border-white shadow-sm">
                      <img src={item.image || bookFallback(item.title)} alt={item.title}
                        className="w-full h-full object-cover" onError={e => e.target.src = bookFallback(item.title)} />
                    </div>
                  ))}
                  {order.items.length > 3 && (
                    <div className="w-10 h-14 rounded-lg bg-ink-200 border-2 border-white flex items-center justify-center text-xs font-bold text-ink-600">
                      +{order.items.length - 3}
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-sans font-semibold text-sm text-ink-800 line-clamp-1">
                        {order.items.map(i => i.title).join(', ')}
                      </p>
                      <p className="text-xs text-ink-400 font-sans mt-0.5">
                        {order.items.length} item{order.items.length > 1 ? 's' : ''} • {formatDate(order.createdAt)}
                      </p>
                    </div>
                    <ChevronRight size={16} className="text-ink-300 group-hover:text-brand-500 flex-shrink-0 mt-0.5 transition-colors" />
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className={`badge ${statusColor(order.status)} flex items-center gap-1`}>
                      {statusIcons[order.status]} {order.status}
                    </span>
                    <span className="font-display font-bold text-ink-900">{formatPrice(order.finalAmount)}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          <Pagination pagination={pagination} onPageChange={setPage} />
        </>
      )}
    </div>
  );
}

// ── Order Detail ──────────────────────────────────────────────────────────────
export function OrderDetailPage() {
  const { id } = useParams();
  const location = useLocation();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);
  const isNew = location.state?.newOrder;

  useEffect(() => {
    api.get(`/orders/${id}`).then(r => { setOrder(r.data.order); setLoading(false); }).catch(() => setLoading(false));
  }, [id]);

  const handleCancel = async () => {
    if (!window.confirm('Are you sure you want to cancel this order?')) return;
    setCancelling(true);
    try {
      const res = await api.put(`/orders/${id}/cancel`, { reason: 'Cancelled by user' });
      setOrder(res.data.order);
      toast.success('Order cancelled');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cannot cancel order');
    }
    setCancelling(false);
  };

  if (loading) return <LoadingSpinner className="py-20" />;
  if (!order) return <div className="text-center py-20 text-ink-500 font-sans">Order not found.</div>;

  const a = order.shippingAddress;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <Breadcrumb items={[{ label: 'Orders', to: '/orders' }, { label: `Order #${order._id.slice(-8).toUpperCase()}` }]} />

      {isNew && (
        <div className="bg-green-50 border border-green-200 rounded-2xl p-5 mb-6 flex items-center gap-3">
          <CheckCircle size={24} className="text-green-500 flex-shrink-0" />
          <div>
            <p className="font-sans font-bold text-green-800">Order Placed Successfully!</p>
            <p className="text-sm text-green-600 font-sans">We'll send updates as your order progresses.</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="card p-6 mb-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="font-display font-bold text-xl text-ink-900">Order #{order._id.slice(-8).toUpperCase()}</h1>
            <p className="text-sm text-ink-500 font-sans mt-0.5">Placed on {formatDate(order.createdAt)}</p>
          </div>
          <span className={`badge text-sm ${statusColor(order.status)} flex items-center gap-1.5 px-3 py-1.5`}>
            {statusIcons[order.status]} {order.status}
          </span>
        </div>

        {/* Timeline */}
        {order.statusHistory?.length > 0 && (
          <div className="mt-5 pt-5 border-t border-ink-100">
            <p className="text-xs font-sans font-semibold text-ink-500 uppercase tracking-wide mb-3">Order Timeline</p>
            <div className="space-y-2">
              {order.statusHistory.map((h, i) => (
                <div key={i} className="flex items-center gap-3 text-sm font-sans">
                  <div className="w-2 h-2 rounded-full bg-brand-400 flex-shrink-0" />
                  <span className="font-semibold text-ink-800">{h.status}</span>
                  {h.note && <span className="text-ink-500">— {h.note}</span>}
                  <span className="ml-auto text-ink-400 text-xs">{formatDate(h.timestamp)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Items */}
      <div className="card p-6 mb-5">
        <h2 className="font-display font-bold text-base mb-4">Order Items</h2>
        <div className="space-y-4">
          {order.items.map((item, i) => (
            <div key={i} className="flex gap-4">
              <Link to={`/books/${item.book}`} className="flex-shrink-0">
                <div className="w-14 h-20 rounded-xl overflow-hidden bg-ink-100">
                  <img src={item.image || bookFallback(item.title)} alt={item.title}
                    className="w-full h-full object-cover" onError={e => e.target.src = bookFallback(item.title)} />
                </div>
              </Link>
              <div className="flex-1">
                <Link to={`/books/${item.book}`} className="font-sans font-semibold text-sm text-ink-900 hover:text-brand-600 transition-colors line-clamp-2">
                  {item.title}
                </Link>
                <p className="text-xs text-ink-500 font-sans">{item.author}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-ink-600 font-sans">Qty: {item.quantity}</span>
                  <span className="font-display font-bold text-ink-900">{formatPrice(item.price * item.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Price summary */}
        <div className="mt-5 pt-4 border-t border-ink-100 space-y-2 text-sm font-sans">
          <div className="flex justify-between text-ink-600"><span>Subtotal</span><span>{formatPrice(order.totalAmount)}</span></div>
          <div className="flex justify-between text-ink-600"><span>Shipping</span>{order.shippingCost === 0 ? <span className="text-green-600">FREE</span> : <span>{formatPrice(order.shippingCost)}</span>}</div>
          <div className="flex justify-between font-bold text-ink-900 text-base pt-1 border-t border-ink-100">
            <span>Total</span><span className="font-display font-black">{formatPrice(order.finalAmount)}</span>
          </div>
        </div>
      </div>

      {/* Shipping & Payment */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
        <div className="card p-5">
          <h3 className="font-sans font-bold text-sm text-ink-800 mb-3">Shipping Address</h3>
          <div className="text-sm text-ink-600 font-sans space-y-0.5">
            <p className="font-semibold text-ink-800">{a.name}</p>
            <p>{a.phone}</p>
            <p>{a.street}</p>
            <p>{a.city}, {a.state} - {a.pincode}</p>
            <p>{a.country}</p>
          </div>
        </div>
        <div className="card p-5">
          <h3 className="font-sans font-bold text-sm text-ink-800 mb-3">Payment Info</h3>
          <div className="space-y-2 text-sm font-sans">
            <div className="flex justify-between"><span className="text-ink-500">Method</span><span className="font-medium text-ink-800 capitalize">{order.paymentMethod}</span></div>
            <div className="flex justify-between"><span className="text-ink-500">Status</span>
              <span className={`font-semibold capitalize ${order.paymentStatus === 'paid' ? 'text-green-600' : order.paymentStatus === 'failed' ? 'text-red-600' : 'text-amber-600'}`}>
                {order.paymentStatus}
              </span>
            </div>
            {order.trackingNumber && (
              <div className="flex justify-between"><span className="text-ink-500">Tracking</span><span className="font-mono text-xs">{order.trackingNumber}</span></div>
            )}
          </div>
        </div>
      </div>

      {/* Cancel button */}
      {!['Shipped','Delivered','Cancelled','Returned'].includes(order.status) && (
        <button onClick={handleCancel} disabled={cancelling}
          className="w-full py-3 border-2 border-red-200 text-red-600 hover:bg-red-50 font-sans font-semibold rounded-xl transition-all text-sm">
          {cancelling ? 'Cancelling...' : 'Cancel Order'}
        </button>
      )}
    </div>
  );
}
