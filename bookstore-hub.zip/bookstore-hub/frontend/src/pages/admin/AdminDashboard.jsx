import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Users, BookOpen, ShoppingBag, TrendingUp, UserX, UserCheck, Star, CheckSquare } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import api from '../utils/api';
import { formatPrice, formatDate, statusColor } from '../utils/helpers';
import { LoadingSpinner, Pagination } from '../components/common/index.jsx';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const STATUS_COLORS = { Pending:'#f59e0b', Confirmed:'#3b82f6', Shipped:'#6366f1', Delivered:'#22c55e', Cancelled:'#ef4444' };

export default function AdminDashboard() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [books, setBooks] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({});
  const [search, setSearch] = useState('');

  const fetchDashboard = async () => {
    try { const r = await api.get('/admin/dashboard'); setStats(r.data); } catch (_) {}
  };

  const fetchUsers = async (page = 1) => {
    try {
      const r = await api.get(`/admin/users?page=${page}&limit=15${search ? `&search=${search}` : ''}`);
      setUsers(r.data.users); setPagination(p => ({...p, users: r.data.pagination}));
    } catch (_) {}
  };

  const fetchBooks = async (page = 1) => {
    try {
      const r = await api.get(`/admin/books?page=${page}&limit=15`);
      setBooks(r.data.books); setPagination(p => ({...p, books: r.data.pagination}));
    } catch (_) {}
  };

  const fetchOrders = async (page = 1) => {
    try {
      const r = await api.get(`/orders/admin/all?page=${page}&limit=15`);
      setOrders(r.data.orders); setPagination(p => ({...p, orders: r.data.pagination}));
    } catch (_) {}
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await fetchDashboard();
      setLoading(false);
    };
    load();
  }, []);

  useEffect(() => {
    if (activeSection === 'users') fetchUsers();
    if (activeSection === 'books') fetchBooks();
    if (activeSection === 'orders') fetchOrders();
  }, [activeSection]);

  const handleBlockUser = async (userId, isBlocked) => {
    try {
      await api.put(`/admin/users/${userId}/block`);
      setUsers(us => us.map(u => u._id === userId ? {...u, isBlocked: !isBlocked} : u));
      toast.success(isBlocked ? 'User unblocked' : 'User blocked');
    } catch (_) { toast.error('Failed to update user'); }
  };

  const handleToggleFeatured = async (bookId, isFeatured) => {
    try {
      await api.put(`/admin/books/${bookId}/feature`);
      setBooks(bs => bs.map(b => b._id === bookId ? {...b, isFeatured: !isFeatured} : b));
      toast.success(isFeatured ? 'Removed from featured' : 'Added to featured');
    } catch (_) { toast.error('Failed'); }
  };

  const handleOrderStatus = async (orderId, status) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status });
      setOrders(os => os.map(o => o._id === orderId ? {...o, status} : o));
      toast.success('Order status updated');
    } catch (_) { toast.error('Failed to update status'); }
  };

  const NAV = [
    { key: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { key: 'users', label: 'Users', icon: Users },
    { key: 'books', label: 'Books', icon: BookOpen },
    { key: 'orders', label: 'Orders', icon: ShoppingBag },
  ];

  return (
    <div className="flex min-h-screen bg-ink-50 page-enter">
      {/* Sidebar */}
      <aside className="w-56 bg-ink-950 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-5 border-b border-ink-800">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
              <BookOpen size={15} className="text-white" />
            </div>
            <span className="font-display font-bold text-sm">BookStore Hub</span>
          </Link>
          <span className="badge bg-red-500/20 text-red-300 mt-2 text-[10px]">Admin Panel</span>
        </div>
        <nav className="flex-1 p-3">
          {NAV.map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setActiveSection(key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-sans font-medium transition-all mb-1 ${
                activeSection === key ? 'bg-brand-500 text-white' : 'text-ink-400 hover:bg-ink-800 hover:text-white'
              }`}
            ><Icon size={16} />{label}</button>
          ))}
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto p-6">
        {/* Mobile nav */}
        <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar md:hidden pb-1">
          {NAV.map(({ key, label }) => (
            <button key={key} onClick={() => setActiveSection(key)}
              className={`category-pill flex-shrink-0 ${activeSection === key ? 'category-pill-active' : 'category-pill-inactive'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── Dashboard ── */}
        {activeSection === 'dashboard' && (
          <div>
            <h1 className="font-display font-bold text-2xl text-ink-900 mb-6">Admin Dashboard</h1>
            {loading ? <LoadingSpinner className="py-16" /> : stats && (
              <>
                {/* Stats cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: 'Total Users', value: stats.stats.totalUsers, icon: Users, color: 'bg-blue-100 text-blue-600' },
                    { label: 'Total Books', value: stats.stats.totalBooks, icon: BookOpen, color: 'bg-purple-100 text-purple-600' },
                    { label: 'Total Orders', value: stats.stats.totalOrders, icon: ShoppingBag, color: 'bg-amber-100 text-amber-600' },
                    { label: 'Revenue', value: formatPrice(stats.stats.totalRevenue), icon: TrendingUp, color: 'bg-green-100 text-green-600' },
                  ].map(({ label, value, icon: Icon, color }) => (
                    <div key={label} className="card p-5">
                      <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center mb-3`}>
                        <Icon size={20} />
                      </div>
                      <p className="font-display font-black text-2xl text-ink-900">{value}</p>
                      <p className="text-xs text-ink-500 font-sans mt-0.5">{label}</p>
                    </div>
                  ))}
                </div>

                {/* Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  <div className="card p-5">
                    <h3 className="font-sans font-bold text-sm text-ink-700 mb-4">Monthly Revenue</h3>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={stats.monthlyRevenue.map(d => ({
                        month: MONTHS[d._id.month - 1],
                        revenue: d.revenue,
                      }))}>
                        <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
                        <Tooltip formatter={v => formatPrice(v)} />
                        <Bar dataKey="revenue" fill="#e35d18" radius={[4,4,0,0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="card p-5">
                    <h3 className="font-sans font-bold text-sm text-ink-700 mb-4">Orders by Status</h3>
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie data={stats.ordersByStatus.map(d => ({ name: d._id, value: d.count }))}
                          dataKey="value" cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3}>
                          {stats.ordersByStatus.map((d, i) => (
                            <Cell key={i} fill={STATUS_COLORS[d._id] || '#94a3b8'} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="flex flex-wrap gap-2 justify-center mt-2">
                      {stats.ordersByStatus.map(d => (
                        <span key={d._id} className="flex items-center gap-1 text-xs font-sans">
                          <span className="w-2 h-2 rounded-full" style={{background: STATUS_COLORS[d._id]}} />
                          {d._id} ({d.count})
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Recent orders */}
                <div className="card p-5">
                  <h3 className="font-sans font-bold text-sm text-ink-700 mb-4">Recent Orders</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm font-sans">
                      <thead>
                        <tr className="border-b border-ink-100">
                          <th className="text-left py-2 px-3 text-xs font-semibold text-ink-500 uppercase">Customer</th>
                          <th className="text-left py-2 px-3 text-xs font-semibold text-ink-500 uppercase">Amount</th>
                          <th className="text-left py-2 px-3 text-xs font-semibold text-ink-500 uppercase">Status</th>
                          <th className="text-left py-2 px-3 text-xs font-semibold text-ink-500 uppercase">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        {stats.recentOrders.map(order => (
                          <tr key={order._id} className="border-b border-ink-50 hover:bg-ink-50 transition-colors">
                            <td className="py-2.5 px-3">
                              <p className="font-semibold text-ink-800">{order.user?.name}</p>
                              <p className="text-xs text-ink-400">{order.user?.email}</p>
                            </td>
                            <td className="py-2.5 px-3 font-display font-bold text-ink-900">{formatPrice(order.finalAmount)}</td>
                            <td className="py-2.5 px-3"><span className={`badge ${statusColor(order.status)}`}>{order.status}</span></td>
                            <td className="py-2.5 px-3 text-ink-500 text-xs">{formatDate(order.createdAt)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── Users ── */}
        {activeSection === 'users' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display font-bold text-2xl text-ink-900">Manage Users</h1>
              <input value={search} onChange={e => { setSearch(e.target.value); fetchUsers(); }}
                placeholder="Search users..." className="input w-56 py-2 text-sm" />
            </div>
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm font-sans">
                  <thead className="bg-ink-50 border-b border-ink-200">
                    <tr>
                      {['User','Role','Joined','Status','Actions'].map(h => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-ink-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(user => (
                      <tr key={user._id} className="border-b border-ink-50 hover:bg-ink-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0">
                              <span className="text-xs font-bold text-brand-700">{user.name?.[0]}</span>
                            </div>
                            <div>
                              <p className="font-semibold text-ink-800">{user.name}</p>
                              <p className="text-xs text-ink-400">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4"><span className="badge bg-brand-100 text-brand-700 capitalize">{user.role}</span></td>
                        <td className="py-3 px-4 text-ink-500 text-xs">{formatDate(user.createdAt)}</td>
                        <td className="py-3 px-4">
                          <span className={`badge ${user.isBlocked ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                            {user.isBlocked ? 'Blocked' : 'Active'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {user.role !== 'admin' && (
                            <button onClick={() => handleBlockUser(user._id, user.isBlocked)}
                              className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
                                user.isBlocked ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200'
                              }`}>
                              {user.isBlocked ? <><UserCheck size={12}/>Unblock</> : <><UserX size={12}/>Block</>}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <Pagination pagination={pagination.users} onPageChange={fetchUsers} />
          </div>
        )}

        {/* ── Books ── */}
        {activeSection === 'books' && (
          <div>
            <h1 className="font-display font-bold text-2xl text-ink-900 mb-6">Manage Books</h1>
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm font-sans">
                  <thead className="bg-ink-50 border-b border-ink-200">
                    <tr>
                      {['Book','Category','Price','Stock','Rating','Featured','Actions'].map(h => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-ink-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {books.map(book => (
                      <tr key={book._id} className="border-b border-ink-50 hover:bg-ink-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3 max-w-xs">
                            <div className="w-8 h-11 rounded-lg overflow-hidden bg-ink-100 flex-shrink-0">
                              <img src={book.images?.[0]?.url} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <p className="font-semibold text-ink-800 line-clamp-1">{book.title}</p>
                              <p className="text-xs text-ink-400">{book.author}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4"><span className="badge bg-ink-100 text-ink-600">{book.category}</span></td>
                        <td className="py-3 px-4 font-display font-bold text-ink-800">{formatPrice(book.price)}</td>
                        <td className="py-3 px-4">
                          <span className={book.stock === 0 ? 'text-red-600 font-semibold' : 'text-green-600'}>{book.stock}</span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-1 text-amber-400">
                            <Star size={12} fill="currentColor" />
                            <span className="text-ink-600 text-xs">{Number(book.ratings).toFixed(1)}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`badge ${book.isFeatured ? 'bg-brand-100 text-brand-700' : 'bg-ink-100 text-ink-400'}`}>
                            {book.isFeatured ? 'Yes' : 'No'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <button onClick={() => handleToggleFeatured(book._id, book.isFeatured)}
                            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-brand-100 text-brand-700 hover:bg-brand-200 transition-all">
                            <CheckSquare size={12} />
                            {book.isFeatured ? 'Unfeature' : 'Feature'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <Pagination pagination={pagination.books} onPageChange={fetchBooks} />
          </div>
        )}

        {/* ── Orders ── */}
        {activeSection === 'orders' && (
          <div>
            <h1 className="font-display font-bold text-2xl text-ink-900 mb-6">All Orders</h1>
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm font-sans">
                  <thead className="bg-ink-50 border-b border-ink-200">
                    <tr>
                      {['Order ID','Customer','Amount','Status','Date','Update Status'].map(h => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-ink-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(order => (
                      <tr key={order._id} className="border-b border-ink-50 hover:bg-ink-50">
                        <td className="py-3 px-4">
                          <Link to={`/orders/${order._id}`} className="font-mono text-xs text-brand-600 hover:underline">
                            #{order._id.slice(-8).toUpperCase()}
                          </Link>
                        </td>
                        <td className="py-3 px-4">
                          <p className="font-semibold text-ink-800">{order.user?.name}</p>
                          <p className="text-xs text-ink-400">{order.user?.email}</p>
                        </td>
                        <td className="py-3 px-4 font-display font-bold">{formatPrice(order.finalAmount)}</td>
                        <td className="py-3 px-4"><span className={`badge ${statusColor(order.status)}`}>{order.status}</span></td>
                        <td className="py-3 px-4 text-ink-500 text-xs">{formatDate(order.createdAt)}</td>
                        <td className="py-3 px-4">
                          <select value={order.status} onChange={e => handleOrderStatus(order._id, e.target.value)}
                            className="input py-1.5 text-xs w-36 appearance-none">
                            {['Pending','Confirmed','Shipped','Delivered','Cancelled'].map(s => (
                              <option key={s} value={s}>{s}</option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <Pagination pagination={pagination.orders} onPageChange={fetchOrders} />
          </div>
        )}
      </main>
    </div>
  );
}
