import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { formatPrice, bookFallback } from '../utils/helpers';
import { EmptyState } from '../components/common/index.jsx';

export default function CartPage() {
  const navigate = useNavigate();
  const { cart, updateCartItem, removeFromCart, cartTotal } = useCart();
  const items = cart?.items || [];
  const shipping = cartTotal > 500 ? 0 : 50;
  const finalTotal = cartTotal + shipping;

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-16 page-enter">
        <EmptyState
          icon="🛒"
          title="Your cart is empty"
          description="Looks like you haven't added any books yet. Start exploring our collection!"
          action={<Link to="/books" className="btn-primary">Browse Books</Link>}
        />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <h1 className="font-display font-bold text-3xl text-ink-900 mb-8">
        Shopping Cart <span className="text-ink-400 font-sans text-lg font-normal">({items.length} {items.length === 1 ? 'item' : 'items'})</span>
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(item => {
            const book = item.book;
            if (!book) return null;
            return (
              <div key={item._id || book._id} className="card p-4 flex gap-4 group">
                {/* Cover */}
                <Link to={`/books/${book._id}`} className="flex-shrink-0">
                  <div className="w-20 h-28 rounded-xl overflow-hidden bg-ink-100">
                    <img src={book.images?.[0]?.url || bookFallback(book.title)} alt={book.title}
                      className="w-full h-full object-cover" onError={e => { e.target.src = bookFallback(book.title); }} />
                  </div>
                </Link>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <Link to={`/books/${book._id}`} className="font-display font-semibold text-ink-900 hover:text-brand-600 transition-colors line-clamp-2 leading-snug">
                        {book.title}
                      </Link>
                      <p className="text-sm text-ink-500 font-sans mt-0.5">{book.author}</p>
                      <p className="text-xs text-ink-400 font-sans mt-0.5">{book.category}</p>
                    </div>
                    <button onClick={() => removeFromCart(book._id)}
                      className="text-ink-300 hover:text-red-500 transition-colors p-1.5 hover:bg-red-50 rounded-lg flex-shrink-0">
                      <Trash2 size={16} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-ink-100">
                    {/* Qty controls */}
                    <div className="flex items-center border border-ink-200 rounded-lg overflow-hidden">
                      <button onClick={() => updateCartItem(book._id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-ink-50 transition-colors text-ink-600">
                        <Minus size={13} />
                      </button>
                      <span className="w-8 text-center text-sm font-sans font-semibold">{item.quantity}</span>
                      <button onClick={() => updateCartItem(book._id, item.quantity + 1)}
                        disabled={item.quantity >= book.stock}
                        className="w-8 h-8 flex items-center justify-center hover:bg-ink-50 transition-colors text-ink-600 disabled:opacity-40">
                        <Plus size={13} />
                      </button>
                    </div>

                    {/* Price */}
                    <div className="text-right">
                      <p className="font-display font-bold text-lg text-ink-900">{formatPrice(book.price * item.quantity)}</p>
                      {item.quantity > 1 && (
                        <p className="text-xs text-ink-400 font-sans">{formatPrice(book.price)} × {item.quantity}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="card p-6 sticky top-24">
            <h2 className="font-display font-bold text-xl mb-5">Order Summary</h2>

            <div className="space-y-3 mb-5 pb-5 border-b border-ink-100">
              <div className="flex justify-between text-sm font-sans">
                <span className="text-ink-600">Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
                <span className="font-semibold text-ink-800">{formatPrice(cartTotal)}</span>
              </div>
              <div className="flex justify-between text-sm font-sans">
                <span className="text-ink-600">Shipping</span>
                {shipping === 0
                  ? <span className="text-green-600 font-semibold">FREE</span>
                  : <span className="font-semibold text-ink-800">{formatPrice(shipping)}</span>
                }
              </div>
              {shipping > 0 && (
                <p className="text-xs text-ink-400 font-sans bg-brand-50 text-brand-700 px-3 py-2 rounded-lg">
                  Add {formatPrice(500 - cartTotal)} more for free shipping!
                </p>
              )}
            </div>

            <div className="flex justify-between items-center mb-6">
              <span className="font-display font-bold text-lg text-ink-900">Total</span>
              <span className="font-display font-black text-2xl text-ink-900">{formatPrice(finalTotal)}</span>
            </div>

            {/* Coupon */}
            <div className="flex gap-2 mb-5">
              <div className="relative flex-1">
                <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
                <input placeholder="Coupon code" className="input pl-8 py-2.5 text-sm" />
              </div>
              <button className="btn-secondary text-sm px-4 py-2.5">Apply</button>
            </div>

            <button onClick={() => navigate('/checkout')} className="btn-primary w-full py-3.5 text-base flex items-center justify-center gap-2">
              Proceed to Checkout <ArrowRight size={18} />
            </button>

            <Link to="/books" className="flex items-center justify-center gap-1.5 text-sm text-brand-600 font-sans font-medium mt-4 hover:text-brand-700">
              <ShoppingBag size={14} /> Continue Shopping
            </Link>

            {/* Secure badges */}
            <div className="mt-5 pt-5 border-t border-ink-100">
              <p className="text-xs text-ink-400 font-sans text-center mb-2">Secure & Encrypted Checkout</p>
              <div className="flex items-center justify-center gap-3 text-ink-300 text-[10px] font-sans">
                <span>🔒 SSL Encrypted</span>
                <span>•</span>
                <span>💳 Stripe Secured</span>
                <span>•</span>
                <span>✓ 100% Safe</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
