import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { BookOpen, Eye, EyeOff, Mail, Lock, User, Phone, Store } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

// ── Login ─────────────────────────────────────────────────────────────────────
export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, loading } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const from = location.state?.from || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(form.email, form.password);
    if (result.success) {
      const dest = result.user.role === 'admin' ? '/admin' : result.user.role === 'seller' ? '/seller' : from;
      navigate(dest, { replace: true });
    }
  };

  const fillDemo = (role) => {
    const demos = {
      user:   { email: 'user@bookstore.com',   password: 'user1234'  },
      seller: { email: 'seller@bookstore.com', password: 'seller123' },
      admin:  { email: 'admin@bookstore.com',  password: 'admin123'  },
    };
    setForm(demos[role]);
  };

  return (
    <div className="min-h-screen bg-ink-50 flex items-center justify-center p-4 page-enter">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center">
              <BookOpen size={22} className="text-white" />
            </div>
            <span className="font-display font-bold text-2xl text-ink-900">BookStore Hub</span>
          </Link>
          <h1 className="font-display font-bold text-3xl text-ink-900">Welcome back</h1>
          <p className="text-ink-500 font-sans mt-1">Sign in to your account</p>
        </div>

        <div className="card p-8">
          {/* Demo buttons */}
          <div className="mb-6">
            <p className="text-xs text-ink-500 font-sans font-semibold uppercase tracking-wide mb-2 text-center">Quick Demo Login</p>
            <div className="grid grid-cols-3 gap-2">
              {['user','seller','admin'].map(role => (
                <button key={role} type="button" onClick={() => fillDemo(role)}
                  className="py-1.5 text-xs font-sans font-semibold rounded-lg border border-ink-200 hover:border-brand-400 hover:text-brand-600 capitalize transition-all">
                  {role}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input type="email" value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))}
                  placeholder="you@example.com" required className="input pl-10" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="label mb-0">Password</label>
                <a href="#" className="text-xs text-brand-600 font-sans font-medium hover:text-brand-700">Forgot password?</a>
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input type={showPw ? 'text' : 'password'} value={form.password} onChange={e => setForm(f => ({...f, password: e.target.value}))}
                  placeholder="••••••••" required className="input pl-10 pr-10" />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full py-3 text-base mt-2">
              {loading ? <span className="flex items-center justify-center gap-2"><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />Signing in...</span> : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-sm text-ink-500 font-sans mt-5">
            Don't have an account?{' '}
            <Link to="/register" className="text-brand-600 font-semibold hover:text-brand-700">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Register ──────────────────────────────────────────────────────────────────
export function RegisterPage() {
  const navigate = useNavigate();
  const { register, loading } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', role: 'user', storeName: '' });
  const [showPw, setShowPw] = useState(false);
  const [confirm, setConfirm] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== confirm) { alert('Passwords do not match'); return; }
    const result = await register(form);
    if (result.success) {
      navigate(result.user.role === 'admin' ? '/admin' : result.user.role === 'seller' ? '/seller' : '/', { replace: true });
    }
  };

  return (
    <div className="min-h-screen bg-ink-50 flex items-center justify-center p-4 py-12 page-enter">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center">
              <BookOpen size={22} className="text-white" />
            </div>
            <span className="font-display font-bold text-2xl text-ink-900">BookStore Hub</span>
          </Link>
          <h1 className="font-display font-bold text-3xl text-ink-900">Create account</h1>
          <p className="text-ink-500 font-sans mt-1">Start your reading journey</p>
        </div>

        <div className="card p-8">
          {/* Role toggle */}
          <div className="flex rounded-xl overflow-hidden border border-ink-200 mb-6">
            {[
              { value: 'user', label: '📖 Reader', desc: 'Buy books' },
              { value: 'seller', label: '🏪 Seller', desc: 'Sell books' },
            ].map(opt => (
              <button key={opt.value} type="button" onClick={() => setForm(f => ({...f, role: opt.value}))}
                className={`flex-1 py-2.5 text-sm font-sans font-semibold transition-all ${
                  form.role === opt.value ? 'bg-brand-500 text-white' : 'bg-white text-ink-500 hover:bg-ink-50'
                }`}>
                {opt.label}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))}
                  placeholder="Your full name" required className="input pl-10" />
              </div>
            </div>
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input type="email" value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))}
                  placeholder="you@example.com" required className="input pl-10" />
              </div>
            </div>
            <div>
              <label className="label">Phone (optional)</label>
              <div className="relative">
                <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))}
                  placeholder="+91 XXXXX XXXXX" className="input pl-10" />
              </div>
            </div>
            {form.role === 'seller' && (
              <div>
                <label className="label">Store Name</label>
                <div className="relative">
                  <Store size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                  <input value={form.storeName} onChange={e => setForm(f => ({...f, storeName: e.target.value}))}
                    placeholder="Your bookstore name" required={form.role === 'seller'} className="input pl-10" />
                </div>
              </div>
            )}
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input type={showPw ? 'text' : 'password'} value={form.password} onChange={e => setForm(f => ({...f, password: e.target.value}))}
                  placeholder="Min 6 characters" required minLength={6} className="input pl-10 pr-10" />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div>
              <label className="label">Confirm Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)}
                  placeholder="Repeat your password" required className="input pl-10" />
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full py-3 text-base mt-2">
              {loading ? <span className="flex items-center justify-center gap-2"><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />Creating account...</span> : 'Create Account'}
            </button>
          </form>

          <p className="text-xs text-ink-400 font-sans text-center mt-4">
            By registering you agree to our <a href="#" className="text-brand-600">Terms</a> and <a href="#" className="text-brand-600">Privacy Policy</a>
          </p>
          <p className="text-center text-sm text-ink-500 font-sans mt-3">
            Already have an account?{' '}
            <Link to="/login" className="text-brand-600 font-semibold hover:text-brand-700">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
