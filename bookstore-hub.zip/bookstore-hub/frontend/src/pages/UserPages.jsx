import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, User, Phone, MapPin, Lock, Camera, Plus } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { BookCard, EmptyState, LoadingSpinner } from '../components/common/index.jsx';
import toast from 'react-hot-toast';

// ── Wishlist Page ─────────────────────────────────────────────────────────────
export function WishlistPage() {
  const { wishlist, toggleWishlist } = useCart();
  const books = wishlist?.books || [];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <div className="flex items-center gap-3 mb-8">
        <Heart size={24} className="text-red-500" fill="currentColor" />
        <h1 className="font-display font-bold text-3xl text-ink-900">My Wishlist</h1>
        <span className="badge bg-ink-100 text-ink-600">{books.length} items</span>
      </div>

      {books.length === 0 ? (
        <EmptyState icon="💝" title="Your wishlist is empty" description="Save books you love for later. Start browsing and add books to your wishlist!"
          action={<Link to="/books" className="btn-primary">Explore Books</Link>}
        />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {books.map(book => typeof book === 'object' && book._id && <BookCard key={book._id} book={book} />)}
        </div>
      )}
    </div>
  );
}

// ── Profile Page ──────────────────────────────────────────────────────────────
export function ProfilePage() {
  const { user, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [avatarFile, setAvatarFile] = useState(null);
  const [form, setForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    storeName: user?.storeName || '',
    storeDescription: user?.storeDescription || '',
  });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const formData = new FormData();
      Object.entries(form).forEach(([k, v]) => { if (v) formData.append(k, v); });
      if (avatarFile) formData.append('avatar', avatarFile);

      const res = await api.put('/auth/profile', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      updateUser(res.data.user);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update profile');
    }
    setSaving(false);
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirm) { toast.error('Passwords do not match'); return; }
    setSaving(true);
    try {
      await api.put('/auth/change-password', { currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      toast.success('Password changed!');
      setPwForm({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to change password');
    }
    setSaving(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <h1 className="font-display font-bold text-3xl text-ink-900 mb-8">Profile Settings</h1>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-ink-200 mb-8">
        {[
          { key: 'profile', label: 'Profile', icon: User },
          { key: 'security', label: 'Security', icon: Lock },
          { key: 'addresses', label: 'Addresses', icon: MapPin },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key)}
            className={`flex items-center gap-2 px-5 py-2.5 text-sm font-sans font-semibold border-b-2 transition-all -mb-px ${
              activeTab === key ? 'border-brand-500 text-brand-600' : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          ><Icon size={14} />{label}</button>
        ))}
      </div>

      {activeTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="card p-6 space-y-5">
          {/* Avatar */}
          <div className="flex items-center gap-5">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl overflow-hidden bg-brand-100 flex items-center justify-center">
                {avatarFile ? (
                  <img src={URL.createObjectURL(avatarFile)} alt="" className="w-full h-full object-cover" />
                ) : user?.avatar ? (
                  <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-3xl font-display font-black text-brand-600">{user?.name?.[0]}</span>
                )}
              </div>
              <label className="absolute -bottom-1 -right-1 w-7 h-7 bg-brand-500 rounded-full flex items-center justify-center cursor-pointer hover:bg-brand-600 transition-colors shadow">
                <Camera size={13} className="text-white" />
                <input type="file" accept="image/*" className="hidden" onChange={e => setAvatarFile(e.target.files[0])} />
              </label>
            </div>
            <div>
              <p className="font-sans font-bold text-ink-900">{user?.name}</p>
              <p className="text-sm text-ink-500 font-sans">{user?.email}</p>
              <span className="badge bg-brand-100 text-brand-700 mt-1 capitalize">{user?.role}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Full Name</label>
              <input value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} className="input" />
            </div>
            <div>
              <label className="label">Phone</label>
              <input value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} className="input" />
            </div>
          </div>
          {user?.role === 'seller' && (
            <>
              <div>
                <label className="label">Store Name</label>
                <input value={form.storeName} onChange={e => setForm(f => ({...f, storeName: e.target.value}))} className="input" />
              </div>
              <div>
                <label className="label">Store Description</label>
                <textarea value={form.storeDescription} onChange={e => setForm(f => ({...f, storeDescription: e.target.value}))}
                  rows={3} className="input resize-none" />
              </div>
            </>
          )}
          <button type="submit" disabled={saving} className="btn-primary">
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      )}

      {activeTab === 'security' && (
        <form onSubmit={handleChangePassword} className="card p-6 space-y-4">
          <h2 className="font-display font-bold text-xl">Change Password</h2>
          <div>
            <label className="label">Current Password</label>
            <input type="password" value={pwForm.currentPassword} onChange={e => setPwForm(f => ({...f, currentPassword: e.target.value}))}
              required className="input" placeholder="Current password" />
          </div>
          <div>
            <label className="label">New Password</label>
            <input type="password" value={pwForm.newPassword} onChange={e => setPwForm(f => ({...f, newPassword: e.target.value}))}
              required minLength={6} className="input" placeholder="New password (min 6 chars)" />
          </div>
          <div>
            <label className="label">Confirm New Password</label>
            <input type="password" value={pwForm.confirm} onChange={e => setPwForm(f => ({...f, confirm: e.target.value}))}
              required className="input" placeholder="Repeat new password" />
          </div>
          <button type="submit" disabled={saving} className="btn-primary">
            {saving ? 'Changing...' : 'Change Password'}
          </button>
        </form>
      )}

      {activeTab === 'addresses' && (
        <AddressTab user={user} updateUser={updateUser} />
      )}
    </div>
  );
}

function AddressTab({ user, updateUser }) {
  const [form, setForm] = useState({ street: '', city: '', state: '', pincode: '', country: 'India', isDefault: false });
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const handleAdd = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.post('/auth/address', form);
      updateUser({ ...user, addresses: res.data.addresses });
      setForm({ street: '', city: '', state: '', pincode: '', country: 'India', isDefault: false });
      setShowForm(false);
      toast.success('Address added!');
    } catch (err) {
      toast.error('Failed to add address');
    }
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      {user?.addresses?.length === 0 && !showForm && (
        <div className="card p-8 text-center">
          <MapPin size={32} className="mx-auto text-ink-300 mb-3" />
          <p className="font-sans font-semibold text-ink-600 mb-1">No addresses saved</p>
          <p className="text-sm text-ink-400 font-sans mb-4">Add a delivery address for faster checkout</p>
        </div>
      )}

      {user?.addresses?.map((addr, i) => (
        <div key={i} className="card p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="text-sm font-sans text-ink-700 space-y-0.5">
              <p>{addr.street}</p>
              <p>{addr.city}, {addr.state} - {addr.pincode}</p>
              <p>{addr.country}</p>
            </div>
            {addr.isDefault && <span className="badge bg-brand-100 text-brand-700">Default</span>}
          </div>
        </div>
      ))}

      {showForm ? (
        <form onSubmit={handleAdd} className="card p-5 space-y-3">
          <h3 className="font-sans font-bold text-sm text-ink-800">Add New Address</h3>
          <input value={form.street} onChange={e => setForm(f => ({...f, street: e.target.value}))} placeholder="Street address" required className="input" />
          <div className="grid grid-cols-2 gap-3">
            <input value={form.city} onChange={e => setForm(f => ({...f, city: e.target.value}))} placeholder="City" required className="input" />
            <input value={form.state} onChange={e => setForm(f => ({...f, state: e.target.value}))} placeholder="State" required className="input" />
          </div>
          <input value={form.pincode} onChange={e => setForm(f => ({...f, pincode: e.target.value}))} placeholder="PIN Code" required className="input" />
          <label className="flex items-center gap-2 cursor-pointer text-sm font-sans">
            <input type="checkbox" checked={form.isDefault} onChange={e => setForm(f => ({...f, isDefault: e.target.checked}))} className="accent-brand-500" />
            Set as default address
          </label>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="btn-primary">{saving ? 'Saving...' : 'Save Address'}</button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
          </div>
        </form>
      ) : (
        <button onClick={() => setShowForm(true)} className="w-full py-3 border-2 border-dashed border-ink-300 rounded-xl text-sm font-sans font-semibold text-ink-600 hover:border-brand-400 hover:text-brand-600 transition-all flex items-center justify-center gap-2">
          <Plus size={16} /> Add New Address
        </button>
      )}
    </div>
  );
}
