import { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, Grid3X3, List, X, ChevronDown } from 'lucide-react';
import api from '../utils/api';
import { CATEGORIES, SORT_OPTIONS } from '../utils/helpers';
import { BookCard, BookCardSkeleton, Pagination, EmptyState } from '../components/common/index.jsx';

export default function BooksPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [books, setBooks] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('grid');
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    minRating: searchParams.get('minRating') || '',
    sort: searchParams.get('sort') || 'newest',
    featured: searchParams.get('featured') || '',
    page: Number(searchParams.get('page')) || 1,
  });

  const fetchBooks = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, v); });
      params.set('limit', '12');
      const res = await api.get(`/books?${params.toString()}`);
      setBooks(res.data.books);
      setPagination(res.data.pagination);
    } catch (_) {}
    setLoading(false);
  }, [filters]);

  useEffect(() => { fetchBooks(); }, [fetchBooks]);

  // Sync filters → URL
  useEffect(() => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v && v !== 'newest' && k !== 'page') params.set(k, v); });
    if (filters.page > 1) params.set('page', filters.page);
    setSearchParams(params, { replace: true });
  }, [filters]);

  const updateFilter = (key, value) => setFilters(f => ({ ...f, [key]: value, page: 1 }));
  const clearFilters = () => setFilters({ search: '', category: '', minPrice: '', maxPrice: '', minRating: '', sort: 'newest', featured: '', page: 1 });

  const activeFilterCount = [filters.category, filters.minPrice, filters.maxPrice, filters.minRating, filters.featured].filter(Boolean).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 page-enter">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display font-bold text-2xl text-ink-900">
            {filters.category || filters.search ? (filters.category || `"${filters.search}"`) : 'All Books'}
          </h1>
          {pagination && (
            <p className="text-sm text-ink-500 font-sans mt-0.5">{pagination.total} books found</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {/* Sort */}
          <div className="relative">
            <select
              value={filters.sort}
              onChange={e => updateFilter('sort', e.target.value)}
              className="input pr-8 py-2 text-sm appearance-none cursor-pointer min-w-[160px]"
            >
              {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none" />
          </div>
          {/* Filter toggle (mobile) */}
          <button onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-1.5 btn-secondary text-sm px-3 py-2 relative"
          >
            <SlidersHorizontal size={15} /> Filters
            {activeFilterCount > 0 && <span className="ml-1 badge bg-brand-500 text-white">{activeFilterCount}</span>}
          </button>
          {/* View toggle */}
          <div className="flex border border-ink-200 rounded-lg overflow-hidden">
            <button onClick={() => setView('grid')} className={`p-2 ${view === 'grid' ? 'bg-brand-500 text-white' : 'bg-white text-ink-500 hover:bg-ink-50'} transition-colors`}><Grid3X3 size={15} /></button>
            <button onClick={() => setView('list')} className={`p-2 ${view === 'list' ? 'bg-brand-500 text-white' : 'bg-white text-ink-500 hover:bg-ink-50'} transition-colors`}><List size={15} /></button>
          </div>
        </div>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-1">
        <button onClick={() => updateFilter('category', '')}
          className={`category-pill flex-shrink-0 ${!filters.category ? 'category-pill-active' : 'category-pill-inactive'}`}
        >All</button>
        {CATEGORIES.map(({ name, icon }) => (
          <button key={name} onClick={() => updateFilter('category', filters.category === name ? '' : name)}
            className={`category-pill flex-shrink-0 flex items-center gap-1.5 ${filters.category === name ? 'category-pill-active' : 'category-pill-inactive'}`}
          >
            <span>{icon}</span> {name}
          </button>
        ))}
      </div>

      <div className="flex gap-6">
        {/* Sidebar Filters */}
        <aside className={`${filtersOpen ? 'block' : 'hidden'} lg:block w-full lg:w-56 flex-shrink-0`}>
          <div className="card p-5 sticky top-24">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-sans font-bold text-sm text-ink-800">Filters</h3>
              {activeFilterCount > 0 && (
                <button onClick={clearFilters} className="text-xs text-brand-600 font-sans font-medium flex items-center gap-1 hover:text-brand-700">
                  <X size={11} /> Clear all
                </button>
              )}
            </div>

            {/* Price Range */}
            <div className="mb-5">
              <label className="label text-xs uppercase tracking-wide text-ink-500">Price Range</label>
              <div className="flex gap-2 mt-2">
                <input type="number" placeholder="Min" value={filters.minPrice} onChange={e => updateFilter('minPrice', e.target.value)}
                  className="input py-1.5 text-sm" />
                <input type="number" placeholder="Max" value={filters.maxPrice} onChange={e => updateFilter('maxPrice', e.target.value)}
                  className="input py-1.5 text-sm" />
              </div>
            </div>

            {/* Rating */}
            <div className="mb-5">
              <label className="label text-xs uppercase tracking-wide text-ink-500">Min Rating</label>
              <div className="space-y-1.5 mt-2">
                {[4, 3, 2, 1].map(r => (
                  <button key={r} onClick={() => updateFilter('minRating', filters.minRating == r ? '' : r)}
                    className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-sans transition-colors ${filters.minRating == r ? 'bg-brand-50 text-brand-700 border border-brand-200' : 'hover:bg-ink-50 text-ink-600'}`}
                  >
                    {'★'.repeat(r)}{'☆'.repeat(5 - r)} <span className="text-xs">{r}+ stars</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Featured */}
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={filters.featured === 'true'} onChange={e => updateFilter('featured', e.target.checked ? 'true' : '')}
                  className="w-4 h-4 rounded border-ink-300 text-brand-500 focus:ring-brand-400" />
                <span className="text-sm font-sans text-ink-700">Featured Only</span>
              </label>
            </div>
          </div>
        </aside>

        {/* Books Grid */}
        <div className="flex-1 min-w-0">
          {loading ? (
            <div className={`grid gap-4 ${view === 'grid' ? 'grid-cols-2 md:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
              {Array(12).fill(0).map((_, i) => <BookCardSkeleton key={i} />)}
            </div>
          ) : books.length === 0 ? (
            <EmptyState icon="📚" title="No books found" description="Try adjusting your search or filter criteria."
              action={<button onClick={clearFilters} className="btn-primary">Clear Filters</button>}
            />
          ) : (
            <>
              <div className={`grid gap-4 ${view === 'grid' ? 'grid-cols-2 md:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
                {books.map(book => <BookCard key={book._id} book={book} view={view} />)}
              </div>
              <Pagination pagination={pagination} onPageChange={p => setFilters(f => ({ ...f, page: p }))} />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
