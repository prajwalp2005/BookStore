/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50:  '#fdf4ee',
          100: '#fae4d0',
          200: '#f5c49e',
          300: '#ef9e66',
          400: '#e87a37',
          500: '#e35d18',
          600: '#c74610',
          700: '#a53310',
          800: '#852a13',
          900: '#6d2412',
          950: '#3b0f07',
        },
        ink: {
          50:  '#f5f5f0',
          100: '#e8e8e0',
          200: '#d0d0c4',
          300: '#b0b09e',
          400: '#888876',
          500: '#6c6c5c',
          600: '#555548',
          700: '#44443a',
          800: '#393930',
          900: '#31312b',
          950: '#1a1a16',
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        body:    ['"Source Serif 4"', 'Georgia', 'serif'],
        sans:    ['"DM Sans"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'book': '4px 4px 0px 0px rgba(0,0,0,0.15)',
        'book-hover': '6px 6px 0px 0px rgba(0,0,0,0.20)',
      },
    },
  },
  plugins: [],
}
