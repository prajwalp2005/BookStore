const express = require('express');
const router = express.Router();
const { register, login, getMe, updateProfile, changePassword, addAddress } = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, getMe);
router.put('/profile', protect, upload.single('avatar'), updateProfile);
router.put('/change-password', protect, changePassword);
router.post('/address', protect, addAddress);

module.exports = router;
