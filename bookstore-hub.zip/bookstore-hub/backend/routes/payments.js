const express = require('express');
const router = express.Router();
const { createPaymentIntent, confirmPayment, confirmCOD } = require('../controllers/paymentController');
const { protect } = require('../middleware/auth');

router.post('/create-intent', protect, createPaymentIntent);
router.post('/confirm', protect, confirmPayment);
router.post('/cod', protect, confirmCOD);

module.exports = router;
