const express = require('express');
const router = express.Router();
const {
  getDashboard, getUsers, toggleBlockUser, updateUserRole,
  approveBook, getAllBooks, toggleFeatured,
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));

router.get('/dashboard', getDashboard);
router.get('/users', getUsers);
router.put('/users/:id/block', toggleBlockUser);
router.put('/users/:id/role', updateUserRole);
router.get('/books', getAllBooks);
router.put('/books/:id/approve', approveBook);
router.put('/books/:id/feature', toggleFeatured);

module.exports = router;
