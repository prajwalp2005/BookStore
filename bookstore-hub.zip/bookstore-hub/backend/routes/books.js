const express = require('express');
const router = express.Router();
const {
  getBooks, getBook, createBook, updateBook, deleteBook,
  getSellerBooks, getCategories, getRecommendations,
} = require('../controllers/bookController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', getBooks);
router.get('/categories', getCategories);
router.get('/seller/mine', protect, authorize('seller', 'admin'), getSellerBooks);
router.get('/:id', getBook);
router.get('/:id/recommendations', getRecommendations);
router.post('/', protect, authorize('seller', 'admin'), upload.array('images', 5), createBook);
router.put('/:id', protect, authorize('seller', 'admin'), upload.array('images', 5), updateBook);
router.delete('/:id', protect, authorize('seller', 'admin'), deleteBook);

module.exports = router;
