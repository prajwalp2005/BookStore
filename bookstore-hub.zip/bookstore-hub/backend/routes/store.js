const express = require('express');
const router = express.Router();
const {
  getCart, addToCart, updateCartItem, removeFromCart, clearCart,
  getWishlist, toggleWishlist,
  getReviews, createReview, deleteReview,
} = require('../controllers/storeController');
const { protect } = require('../middleware/auth');

// Cart
router.get('/cart', protect, getCart);
router.post('/cart', protect, addToCart);
router.put('/cart', protect, updateCartItem);
router.delete('/cart/:bookId', protect, removeFromCart);
router.delete('/cart', protect, clearCart);

// Wishlist
router.get('/wishlist', protect, getWishlist);
router.post('/wishlist', protect, toggleWishlist);

// Reviews
router.get('/reviews/:bookId', getReviews);
router.post('/reviews', protect, createReview);
router.delete('/reviews/:id', protect, deleteReview);

module.exports = router;
