require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Book = require('../models/Book');

const connectDB = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('MongoDB connected for seeding');
};

const CATEGORIES = ['Fiction','Non-Fiction','Academic','Science','Technology','History','Biography','Self-Help','Children','Mystery','Romance','Fantasy'];

const BOOKS_DATA = [
  { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', category: 'Fiction', price: 299, originalPrice: 399, stock: 50, description: 'A story of the fabulously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan.', tags: ['classic', 'american', 'literature'], ratings: 4.5, numReviews: 1243, isFeatured: true, pages: 180, publisher: 'Scribner', language: 'English' },
  { title: 'To Kill a Mockingbird', author: 'Harper Lee', category: 'Fiction', price: 349, originalPrice: 449, stock: 35, description: 'A gripping, heart-wrenching, and wholly remarkable tale of coming-of-age in a South plagued by racism.', tags: ['classic', 'race', 'justice'], ratings: 4.8, numReviews: 3241, isFeatured: true, pages: 281, publisher: 'J. B. Lippincott', language: 'English' },
  { title: 'Clean Code', author: 'Robert C. Martin', category: 'Technology', price: 599, originalPrice: 799, stock: 20, description: 'A handbook of agile software craftsmanship. Every programmer should read this book.', tags: ['programming', 'software', 'coding'], ratings: 4.7, numReviews: 5621, isFeatured: true, pages: 464, publisher: 'Prentice Hall', language: 'English' },
  { title: 'Sapiens: A Brief History of Humankind', author: 'Yuval Noah Harari', category: 'History', price: 449, originalPrice: 599, stock: 40, description: 'A brief history of humankind from the Stone Age to the twenty-first century.', tags: ['history', 'humanity', 'evolution'], ratings: 4.6, numReviews: 8932, isFeatured: true, pages: 443, publisher: 'Harper', language: 'English' },
  { title: 'Atomic Habits', author: 'James Clear', category: 'Self-Help', price: 399, originalPrice: 499, stock: 60, description: 'An Easy & Proven Way to Build Good Habits & Break Bad Ones.', tags: ['habits', 'productivity', 'self-improvement'], ratings: 4.9, numReviews: 12450, isFeatured: true, pages: 320, publisher: 'Avery', language: 'English' },
  { title: '1984', author: 'George Orwell', category: 'Fiction', price: 249, originalPrice: 349, stock: 45, description: 'A dystopian social science fiction novel set in a totalitarian superstate.', tags: ['dystopia', 'classic', 'politics'], ratings: 4.7, numReviews: 7823, isFeatured: false, pages: 328, publisher: 'Secker & Warburg', language: 'English' },
  { title: 'The Alchemist', author: 'Paulo Coelho', category: 'Fiction', price: 299, originalPrice: 399, stock: 55, description: 'A magical story about following your dreams and listening to your heart.', tags: ['inspirational', 'journey', 'dreams'], ratings: 4.5, numReviews: 9234, isFeatured: false, pages: 197, publisher: 'HarperOne', language: 'English' },
  { title: 'Harry Potter and the Sorcerer\'s Stone', author: 'J.K. Rowling', category: 'Fantasy', price: 499, originalPrice: 599, stock: 80, description: 'A young boy discovers he is a wizard and attends Hogwarts School of Witchcraft and Wizardry.', tags: ['magic', 'wizard', 'adventure'], ratings: 4.9, numReviews: 15678, isFeatured: true, pages: 309, publisher: 'Bloomsbury', language: 'English' },
  { title: 'The Psychology of Money', author: 'Morgan Housel', category: 'Non-Fiction', price: 349, originalPrice: 449, stock: 30, description: 'Timeless lessons on wealth, greed, and happiness.', tags: ['finance', 'money', 'investing'], ratings: 4.7, numReviews: 6789, isFeatured: true, pages: 256, publisher: 'Harriman House', language: 'English' },
  { title: 'Introduction to Algorithms', author: 'Thomas H. Cormen', category: 'Academic', price: 899, originalPrice: 1199, stock: 15, description: 'Comprehensive introduction to algorithms, now in its fourth edition.', tags: ['algorithms', 'computer science', 'data structures'], ratings: 4.6, numReviews: 3456, isFeatured: false, pages: 1292, publisher: 'MIT Press', language: 'English' },
  { title: 'A Brief History of Time', author: 'Stephen Hawking', category: 'Science', price: 349, originalPrice: 449, stock: 25, description: 'A landmark volume in science writing by one of the great minds of our time.', tags: ['physics', 'universe', 'cosmology'], ratings: 4.6, numReviews: 4532, isFeatured: false, pages: 212, publisher: 'Bantam Books', language: 'English' },
  { title: 'Think and Grow Rich', author: 'Napoleon Hill', category: 'Self-Help', price: 249, originalPrice: 299, stock: 70, description: 'The classic that has made millionaires. The secrets to personal achievement and wealth.', tags: ['success', 'wealth', 'mindset'], ratings: 4.4, numReviews: 8901, isFeatured: false, pages: 238, publisher: 'The Ralston Society', language: 'English' },
  { title: 'The Da Vinci Code', author: 'Dan Brown', category: 'Mystery', price: 349, originalPrice: 499, stock: 40, description: 'A murder in the Louvre and clues in Da Vinci paintings lead to the discovery of a religious mystery.', tags: ['mystery', 'thriller', 'religion'], ratings: 4.3, numReviews: 11234, isFeatured: false, pages: 454, publisher: 'Doubleday', language: 'English' },
  { title: 'Pride and Prejudice', author: 'Jane Austen', category: 'Romance', price: 199, originalPrice: 299, stock: 35, description: 'A story of manners, upbringing, morality, education, and marriage in early 19th-century England.', tags: ['classic', 'romance', 'society'], ratings: 4.7, numReviews: 7654, isFeatured: false, pages: 432, publisher: 'T. Egerton', language: 'English' },
  { title: 'The Lean Startup', author: 'Eric Ries', category: 'Non-Fiction', price: 399, originalPrice: 499, stock: 28, description: 'How Today\'s Entrepreneurs Use Continuous Innovation to Create Radically Successful Businesses.', tags: ['startup', 'entrepreneurship', 'business'], ratings: 4.5, numReviews: 5432, isFeatured: false, pages: 336, publisher: 'Crown Business', language: 'English' },
  { title: 'Dune', author: 'Frank Herbert', category: 'Fiction', price: 449, originalPrice: 549, stock: 32, description: 'Set in the distant future amidst a feudal interstellar society, Dune tells the story of young Paul Atreides.', tags: ['sci-fi', 'epic', 'space'], ratings: 4.8, numReviews: 9876, isFeatured: true, pages: 896, publisher: 'Chilton Books', language: 'English' },
  { title: 'The Midnight Library', author: 'Matt Haig', category: 'Fiction', price: 379, originalPrice: 479, stock: 42, description: 'Between life and death there is a library where every book represents a different life you could have lived.', tags: ['contemporary', 'philosophy', 'life'], ratings: 4.5, numReviews: 6543, isFeatured: false, pages: 304, publisher: 'Canongate Books', language: 'English' },
  { title: 'Educated', author: 'Tara Westover', category: 'Biography', price: 399, originalPrice: 499, stock: 22, description: 'A memoir about a young girl who grows up in a survivalist family and goes on to earn a PhD from Cambridge.', tags: ['memoir', 'education', 'family'], ratings: 4.7, numReviews: 7832, isFeatured: false, pages: 352, publisher: 'Random House', language: 'English' },
];

const COVER_IMAGES = [
  'https://covers.openlibrary.org/b/id/8739161-L.jpg',
  'https://covers.openlibrary.org/b/id/8228691-L.jpg',
  'https://covers.openlibrary.org/b/id/10909258-L.jpg',
  'https://covers.openlibrary.org/b/id/8091016-L.jpg',
  'https://covers.openlibrary.org/b/id/10527843-L.jpg',
];

const seedDatabase = async () => {
  try {
    await connectDB();

    // Clear existing data
    await User.deleteMany({});
    await Book.deleteMany({});
    console.log('Cleared existing data');

    // Create admin
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@bookstore.com',
      password: 'admin123',
      role: 'admin',
      phone: '9999999999',
    });

    // Create seller
    const seller = await User.create({
      name: 'Book World Seller',
      email: 'seller@bookstore.com',
      password: 'seller123',
      role: 'seller',
      storeName: 'Book World',
      storeDescription: 'Your one-stop shop for all books',
      phone: '8888888888',
    });

    // Create sample user
    await User.create({
      name: 'John Reader',
      email: 'user@bookstore.com',
      password: 'user1234',
      role: 'user',
      phone: '7777777777',
    });

    console.log('✅ Users created');

    // Create books
    const booksToCreate = BOOKS_DATA.map((book, i) => ({
      ...book,
      sellerId: seller._id,
      discount: Math.floor(((book.originalPrice - book.price) / book.originalPrice) * 100),
      images: [{ url: COVER_IMAGES[i % COVER_IMAGES.length], public_id: `seed_${i}` }],
    }));

    await Book.insertMany(booksToCreate);
    console.log(`✅ ${booksToCreate.length} books created`);

    console.log('\n🎉 Database seeded successfully!\n');
    console.log('Demo accounts:');
    console.log('  Admin:  admin@bookstore.com  / admin123');
    console.log('  Seller: seller@bookstore.com / seller123');
    console.log('  User:   user@bookstore.com   / user1234\n');

    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedDatabase();
