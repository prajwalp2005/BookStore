const Order = require('../models/Order');
const { Payment } = require('../models/index');

// @desc    Create payment intent (Stripe)
// @route   POST /api/payments/create-intent
exports.createPaymentIntent = async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    if (order.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Mock Stripe payment intent (replace with real Stripe in production)
    if (process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY !== 'sk_test_your_stripe_secret_key') {
      const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(order.finalAmount * 100),
        currency: 'inr',
        metadata: { orderId: order._id.toString(), userId: req.user._id.toString() },
      });

      res.json({ success: true, clientSecret: paymentIntent.client_secret, paymentIntentId: paymentIntent.id });
    } else {
      // Mock for development
      const mockClientSecret = `mock_${Date.now()}_secret_${Math.random().toString(36).substring(7)}`;
      res.json({ success: true, clientSecret: mockClientSecret, paymentIntentId: `mock_pi_${Date.now()}`, isMock: true });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Confirm payment
// @route   POST /api/payments/confirm
exports.confirmPayment = async (req, res) => {
  try {
    const { orderId, paymentIntentId } = req.body;

    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    order.paymentStatus = 'paid';
    order.status = 'Confirmed';
    order.stripePaymentIntentId = paymentIntentId;
    order.statusHistory.push({ status: 'Confirmed', note: 'Payment confirmed' });
    await order.save();

    await Payment.create({
      order: orderId,
      user: req.user._id,
      stripePaymentIntentId: paymentIntentId,
      amount: order.finalAmount,
      status: 'succeeded',
    });

    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    COD order confirm
// @route   POST /api/payments/cod
exports.confirmCOD = async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    order.status = 'Confirmed';
    order.paymentMethod = 'cod';
    order.statusHistory.push({ status: 'Confirmed', note: 'Cash on delivery order confirmed' });
    await order.save();

    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
