const Book = require('../models/Book');

// @desc    Get all books (with filters, search, pagination)
// @route   GET /api/books
exports.getBooks = async (req, res) => {
  try {
    const {
      search, category, minPrice, maxPrice, minRating,
      author, sort, page = 1, limit = 12, featured,
    } = req.query;

    const query = { isApproved: true, status: 'active' };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { author: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } },
      ];
    }
    if (category) query.category = category;
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }
    if (minRating) query.ratings = { $gte: Number(minRating) };
    if (author) query.author = { $regex: author, $options: 'i' };
    if (featured === 'true') query.isFeatured = true;

    const sortOptions = {
      newest: { createdAt: -1 },
      oldest: { createdAt: 1 },
      'price-asc': { price: 1 },
      'price-desc': { price: -1 },
      rating: { ratings: -1 },
      popular: { numReviews: -1 },
    };
    const sortBy = sortOptions[sort] || { createdAt: -1 };

    const skip = (Number(page) - 1) * Number(limit);
    const total = await Book.countDocuments(query);
    const books = await Book.find(query)
      .populate('sellerId', 'name storeName')
      .sort(sortBy)
      .skip(skip)
      .limit(Number(limit));

    res.json({
      success: true,
      books,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
        limit: Number(limit),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single book
// @route   GET /api/books/:id
exports.getBook = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id).populate('sellerId', 'name storeName storeDescription');
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    res.json({ success: true, book });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create book (seller/admin)
// @route   POST /api/books
exports.createBook = async (req, res) => {
  try {
    const bookData = { ...req.body, sellerId: req.user._id };

    if (req.files && req.files.length > 0) {
      bookData.images = req.files.map((file) => ({
        url: `/uploads/${file.filename}`,
        public_id: file.filename,
      }));
    }

    if (!bookData.images || bookData.images.length === 0) {
      // Default placeholder
      bookData.images = [{ url: `https://picsum.photos/seed/${Date.now()}/400/600`, public_id: 'placeholder' }];
    }

    const book = await Book.create(bookData);
    res.status(201).json({ success: true, book });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Update book
// @route   PUT /api/books/:id
exports.updateBook = async (req, res) => {
  try {
    let book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });

    if (req.user.role !== 'admin' && book.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    if (req.files && req.files.length > 0) {
      req.body.images = req.files.map((f) => ({ url: `/uploads/${f.filename}`, public_id: f.filename }));
    }

    book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json({ success: true, book });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete book
// @route   DELETE /api/books/:id
exports.deleteBook = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });

    if (req.user.role !== 'admin' && book.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    await book.deleteOne();
    res.json({ success: true, message: 'Book deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get seller's books
// @route   GET /api/books/seller/mine
exports.getSellerBooks = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;
    const total = await Book.countDocuments({ sellerId: req.user._id });
    const books = await Book.find({ sellerId: req.user._id })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    res.json({ success: true, books, pagination: { total, page: Number(page), pages: Math.ceil(total / limit) } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get categories with counts
// @route   GET /api/books/categories
exports.getCategories = async (req, res) => {
  try {
    const categories = await Book.aggregate([
      { $match: { isApproved: true, status: 'active' } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    res.json({ success: true, categories });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get recommended books (based on category of viewed book)
// @route   GET /api/books/:id/recommendations
exports.getRecommendations = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });

    const books = await Book.find({
      _id: { $ne: book._id },
      category: book.category,
      isApproved: true,
      status: 'active',
    })
      .sort({ ratings: -1 })
      .limit(6);

    res.json({ success: true, books });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
