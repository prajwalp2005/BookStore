const { Cart, Wishlist, Review } = require('../models/index');
const Book = require('../models/Book');
const Order = require('../models/Order');

// ─── CART ──────────────────────────────────────────────────────────────────────

exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id }).populate('items.book');
    res.json({ success: true, cart: cart || { items: [] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.addToCart = async (req, res) => {
  try {
    const { bookId, quantity = 1 } = req.body;

    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
    if (book.stock < quantity) return res.status(400).json({ success: false, message: 'Insufficient stock' });

    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) cart = new Cart({ user: req.user._id, items: [] });

    const existingIndex = cart.items.findIndex((i) => i.book.toString() === bookId);
    if (existingIndex > -1) {
      cart.items[existingIndex].quantity += quantity;
    } else {
      cart.items.push({ book: bookId, quantity });
    }

    await cart.save();
    await cart.populate('items.book');
    res.json({ success: true, cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateCartItem = async (req, res) => {
  try {
    const { bookId, quantity } = req.body;
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ success: false, message: 'Cart not found' });

    const itemIndex = cart.items.findIndex((i) => i.book.toString() === bookId);
    if (itemIndex === -1) return res.status(404).json({ success: false, message: 'Item not in cart' });

    if (quantity <= 0) {
      cart.items.splice(itemIndex, 1);
    } else {
      cart.items[itemIndex].quantity = quantity;
    }

    await cart.save();
    await cart.populate('items.book');
    res.json({ success: true, cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.removeFromCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ success: false, message: 'Cart not found' });
    cart.items = cart.items.filter((i) => i.book.toString() !== req.params.bookId);
    await cart.save();
    await cart.populate('items.book');
    res.json({ success: true, cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.clearCart = async (req, res) => {
  try {
    await Cart.findOneAndUpdate({ user: req.user._id }, { $set: { items: [] } });
    res.json({ success: true, message: 'Cart cleared' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── WISHLIST ─────────────────────────────────────────────────────────────────

exports.getWishlist = async (req, res) => {
  try {
    const wishlist = await Wishlist.findOne({ user: req.user._id }).populate('books');
    res.json({ success: true, wishlist: wishlist || { books: [] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.toggleWishlist = async (req, res) => {
  try {
    const { bookId } = req.body;
    let wishlist = await Wishlist.findOne({ user: req.user._id });
    if (!wishlist) wishlist = new Wishlist({ user: req.user._id, books: [] });

    const idx = wishlist.books.indexOf(bookId);
    let action;
    if (idx > -1) {
      wishlist.books.splice(idx, 1);
      action = 'removed';
    } else {
      wishlist.books.push(bookId);
      action = 'added';
    }

    await wishlist.save();
    res.json({ success: true, action, wishlist });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── REVIEWS ─────────────────────────────────────────────────────────────────

exports.getReviews = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;
    const total = await Review.countDocuments({ book: req.params.bookId });
    const reviews = await Review.find({ book: req.params.bookId })
      .populate('user', 'name avatar')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    res.json({ success: true, reviews, pagination: { total, page: Number(page), pages: Math.ceil(total / limit) } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.createReview = async (req, res) => {
  try {
    const { bookId, rating, comment, title } = req.body;

    // Check purchased
    const hasPurchased = await Order.findOne({
      user: req.user._id,
      'items.book': bookId,
      status: 'Delivered',
    });

    const existing = await Review.findOne({ user: req.user._id, book: bookId });
    if (existing) return res.status(400).json({ success: false, message: 'You already reviewed this book' });

    const review = await Review.create({
      user: req.user._id,
      book: bookId,
      rating,
      comment,
      title,
      isVerifiedPurchase: !!hasPurchased,
    });

    // Update book rating
    const allReviews = await Review.find({ book: bookId });
    const avgRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;
    await Book.findByIdAndUpdate(bookId, { ratings: avgRating.toFixed(1), numReviews: allReviews.length });

    await review.populate('user', 'name avatar');
    res.status(201).json({ success: true, review });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ success: false, message: 'Review not found' });

    if (req.user.role !== 'admin' && review.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    await review.deleteOne();
    // Recalculate rating
    const allReviews = await Review.find({ book: review.book });
    const avgRating = allReviews.length ? allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length : 0;
    await Book.findByIdAndUpdate(review.book, { ratings: avgRating.toFixed(1), numReviews: allReviews.length });

    res.json({ success: true, message: 'Review deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
