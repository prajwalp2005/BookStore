# 📚 Book Store Hub — Full-Stack MERN Application

A production-ready, full-featured online bookstore platform built with the MERN stack (MongoDB, Express.js, React.js, Node.js).

---

## 🚀 Features

### 👤 User Features
- JWT authentication (register, login, logout)
- Profile management with avatar upload
- Browse books by category, search & filter (price, rating, author)
- Book detail pages with image gallery, description, reviews
- Add to cart / update quantities / remove items
- Full checkout flow (address → payment → review → confirm)
- Payment via Card (Stripe mock) or Cash on Delivery
- Order history with status tracking
- Cancel orders
- Wishlist / Favorites
- Write reviews & ratings (verified purchase badge)

### 📦 Seller Features
- Seller registration & dashboard
- Add, edit, delete book listings
- Manage stock and pricing
- View & update orders (Pending → Confirmed → Shipped → Delivered)
- Sales overview stats

### 👨‍💼 Admin Features
- Secure admin panel
- Dashboard with revenue charts (Recharts), order status breakdown
- Manage all users (block/unblock)
- Feature/unfeature books
- View & update all orders
- User role management

---

## 🛠 Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | React 18, Vite, Tailwind CSS        |
| Backend   | Node.js, Express.js                 |
| Database  | MongoDB, Mongoose                   |
| Auth      | JWT, bcryptjs                       |
| Payments  | Stripe (mock-ready)                 |
| UI        | Recharts, Lucide React, React Hot Toast |
| Fonts     | Playfair Display, Source Serif 4, DM Sans |

---

## 📁 Project Structure

```
bookstore-hub/
├── backend/
│   ├── config/
│   │   └── db.js                  # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js      # Auth: register, login, profile
│   │   ├── bookController.js      # Book CRUD, search, filters
│   │   ├── orderController.js     # Orders, status, cancel
│   │   ├── storeController.js     # Cart, wishlist, reviews
│   │   ├── adminController.js     # Admin dashboard, user/book mgmt
│   │   └── paymentController.js   # Stripe payment intents
│   ├── middleware/
│   │   ├── auth.js                # JWT protect + role authorize
│   │   ├── error.js               # Global error handler
│   │   └── upload.js              # Multer file upload
│   ├── models/
│   │   ├── User.js                # User schema (user/seller/admin)
│   │   ├── Book.js                # Book schema with text indexes
│   │   ├── Order.js               # Order + items + status history
│   │   └── index.js               # Review, Cart, Wishlist, Payment
│   ├── routes/
│   │   ├── auth.js
│   │   ├── books.js
│   │   ├── orders.js
│   │   ├── store.js               # Cart + wishlist + reviews
│   │   ├── admin.js
│   │   └── payments.js
│   ├── utils/
│   │   └── seed.js                # Database seeder
│   ├── uploads/                   # Uploaded images (auto-created)
│   ├── server.js                  # Express entry point
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── common/
    │   │   │   ├── index.jsx      # BookCard, StarRating, Pagination, etc.
    │   │   │   └── RouteGuards.jsx
    │   │   └── layout/
    │   │       ├── Navbar.jsx
    │   │       └── Footer.jsx
    │   ├── context/
    │   │   ├── AuthContext.jsx    # Auth state + actions
    │   │   └── CartContext.jsx    # Cart + wishlist state
    │   ├── pages/
    │   │   ├── HomePage.jsx       # Hero, categories, featured books
    │   │   ├── BooksPage.jsx      # Listing with filters & search
    │   │   ├── BookDetailPage.jsx # Detail, reviews, recommendations
    │   │   ├── CartPage.jsx
    │   │   ├── CheckoutPage.jsx   # 3-step checkout
    │   │   ├── AuthPages.jsx      # Login + Register
    │   │   ├── OrderPages.jsx     # Order list + detail
    │   │   ├── UserPages.jsx      # Wishlist + Profile
    │   │   ├── admin/
    │   │   │   └── AdminDashboard.jsx
    │   │   └── seller/
    │   │       └── SellerDashboard.jsx
    │   ├── utils/
    │   │   ├── api.js             # Axios instance with JWT interceptor
    │   │   └── helpers.js         # Formatters, constants, utilities
    │   ├── App.jsx                # Router + layout wrapper
    │   ├── main.jsx
    │   └── index.css              # Tailwind + custom styles
    ├── index.html
    ├── vite.config.js
    ├── tailwind.config.js
    └── package.json
```

---

## ⚡ Quick Start

### Prerequisites
- Node.js v18+
- MongoDB (local) or MongoDB Atlas URI
- npm or yarn

---

### 1. Clone and setup

```bash
git clone https://github.com/your-username/bookstore-hub.git
cd bookstore-hub
```

---

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy env file and configure
cp .env.example .env
```

Edit `.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/bookstore-hub
JWT_SECRET=your_very_secret_key_here
JWT_EXPIRE=7d
STRIPE_SECRET_KEY=sk_test_...       # Optional - uses mock if not set
FRONTEND_URL=http://localhost:5173
```

```bash
# Seed the database with demo data
npm run seed

# Start development server
npm run dev
```

Backend runs at: `http://localhost:5000`

---

### 3. Frontend Setup

```bash
cd ../frontend

# Install dependencies
npm install

# Copy env file
cp .env.example .env
```

Edit `.env`:
```
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...   # Optional
```

```bash
# Start development server
npm run dev
```

Frontend runs at: `http://localhost:5173`

---

## 🔐 Demo Accounts (after seeding)

| Role   | Email                    | Password   |
|--------|--------------------------|------------|
| Admin  | admin@bookstore.com      | admin123   |
| Seller | seller@bookstore.com     | seller123  |
| User   | user@bookstore.com       | user1234   |

> You can also use the **Quick Demo Login** buttons on the login page.

---

## 🔗 API Endpoints

### Auth
```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me
PUT    /api/auth/profile
PUT    /api/auth/change-password
POST   /api/auth/address
```

### Books
```
GET    /api/books                        # List (search, filter, paginate)
GET    /api/books/categories             # Category counts
GET    /api/books/seller/mine            # Seller's own books
GET    /api/books/:id
GET    /api/books/:id/recommendations
POST   /api/books                        # Create (seller/admin)
PUT    /api/books/:id                    # Update (seller/admin)
DELETE /api/books/:id                    # Delete (seller/admin)
```

### Cart & Wishlist
```
GET    /api/store/cart
POST   /api/store/cart
PUT    /api/store/cart
DELETE /api/store/cart/:bookId
DELETE /api/store/cart
GET    /api/store/wishlist
POST   /api/store/wishlist
```

### Reviews
```
GET    /api/store/reviews/:bookId
POST   /api/store/reviews
DELETE /api/store/reviews/:id
```

### Orders
```
POST   /api/orders
GET    /api/orders/my
GET    /api/orders/admin/all
GET    /api/orders/seller/mine
GET    /api/orders/:id
PUT    /api/orders/:id/status
PUT    /api/orders/:id/cancel
```

### Payments
```
POST   /api/payments/create-intent
POST   /api/payments/confirm
POST   /api/payments/cod
```

### Admin
```
GET    /api/admin/dashboard
GET    /api/admin/users
PUT    /api/admin/users/:id/block
PUT    /api/admin/users/:id/role
GET    /api/admin/books
PUT    /api/admin/books/:id/approve
PUT    /api/admin/books/:id/feature
```

---

## 💳 Payment Setup

The app works out of the box with **mock payments** (no Stripe keys needed for development).

To enable real Stripe payments:
1. Create a Stripe account at stripe.com
2. Get your API keys from the Stripe Dashboard
3. Add to backend `.env`: `STRIPE_SECRET_KEY=sk_test_...`
4. Add to frontend `.env`: `VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...`

---

## 🚢 Deployment

### Backend → Render
1. Push to GitHub
2. Create new Web Service on Render
3. Set build command: `npm install`
4. Set start command: `node server.js`
5. Add all environment variables

### Frontend → Vercel
1. Import GitHub repo on Vercel
2. Set framework: Vite
3. Add environment variables
4. Deploy

### Database → MongoDB Atlas
1. Create cluster at cloud.mongodb.com
2. Get connection string
3. Set `MONGO_URI` in both backend env and Render env vars

---

## 🎨 Design Highlights

- **Typography**: Playfair Display (headings) + Source Serif 4 (body) + DM Sans (UI)
- **Color palette**: Warm brand orange (#e35d18) on deep ink backgrounds
- **Components**: Fully custom with Tailwind — no component library bloat
- **Responsive**: Mobile-first, works on all screen sizes
- **Animations**: CSS keyframe transitions, hover states, skeleton loaders
- **Accessibility**: Semantic HTML, focus states, ARIA labels

---

## 📝 License

MIT © 2024 Book Store Hub
